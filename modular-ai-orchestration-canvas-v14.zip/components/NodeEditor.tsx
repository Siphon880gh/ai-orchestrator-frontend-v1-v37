
import React, { useState, useRef, useEffect } from 'react';
import { Node } from 'reactflow';
import { CanvasNodeData, NodeType, RunState, ChatMessage } from '../types';
import { geminiService } from '../services/geminiService';
import { 
  Play, 
  Trash2, 
  X as CloseIcon, 
  Code2,
  Sparkles,
  Database,
  Terminal,
  ArrowDownToLine,
  Info,
  StickyNote as StickyIcon,
  Palette,
  MessageSquare,
  Send,
  CheckCircle,
  RefreshCcw,
  MessageCircle,
  Zap,
  Activity,
  Layers,
  Cpu,
  Shield,
  Search,
  Hash,
  ChevronDown,
  ChevronRight,
  History,
  MessageSquareText
} from 'lucide-react';

interface NodeEditorProps {
  node: Node<CanvasNodeData> | null;
  onUpdate: (id: string, newData: Partial<CanvasNodeData>) => void;
  onRun: (id: string) => void;
  onDelete: (id: string) => void;
  onClose: () => void;
  upstreamNodes?: { id: string, label: string, output: string }[];
}

const PRESET_COLORS = [
  { name: 'Slate', value: 'rgba(30, 41, 59, 0.6)' },
  { name: 'Amber', value: 'rgba(180, 83, 9, 0.6)' },
  { name: 'Emerald', value: 'rgba(4, 120, 87, 0.6)' },
  { name: 'Rose', value: 'rgba(190, 18, 60, 0.6)' },
  { name: 'Indigo', value: 'rgba(67, 56, 202, 0.6)' },
  { name: 'Purple', value: 'rgba(126, 34, 206, 0.6)' },
  { name: 'Cyan', value: 'rgba(14, 116, 144, 0.6)' },
];

const GLOW_COLORS = [
  { name: 'Purple', value: '#a855f7' },
  { name: 'Blue', value: '#3b82f6' },
  { name: 'Emerald', value: '#10b981' },
  { name: 'Rose', value: '#f43f5e' },
  { name: 'Amber', value: '#f59e0b' },
  { name: 'Cyan', value: '#06b6d4' },
];

const ICONS = [
  { name: 'Sparkles', component: Sparkles },
  { name: 'Database', component: Database },
  { name: 'Terminal', component: Terminal },
  { name: 'Zap', component: Zap },
  { name: 'Activity', component: Activity },
  { name: 'Layers', component: Layers },
  { name: 'Cpu', component: Cpu },
  { name: 'Shield', component: Shield },
  { name: 'Search', component: Search },
  { name: 'Hash', component: Hash },
];

const NodeEditor: React.FC<NodeEditorProps> = ({ node, onUpdate, onRun, onDelete, onClose, upstreamNodes = [] }) => {
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const [isVisualExpanded, setIsVisualExpanded] = useState(false);
  const [isRecallOpen, setIsRecallOpen] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
    return () => clearTimeout(timeoutId);
  }, [node?.data?.chatHistory, isChatting]);

  if (!node) return null;

  const { data } = node;
  const isDataNode = data.type === NodeType.DATA_INPUT;
  const isAiPromptNode = data.type === NodeType.AI_PROMPT;
  const isRefactorNode = data.type === NodeType.REFACTOR;
  const isLogicNode = isAiPromptNode || isRefactorNode;
  const isStickyNode = data.type === NodeType.STICKY_NOTE;

  const canUseChat = isAiPromptNode;
  const activeChatMode = canUseChat && data.isChatMode;

  const handleSendChat = async () => {
    if (!chatInput.trim() || isChatting || !canUseChat) return;
    setIsChatting(true);
    const message = chatInput;
    setChatInput('');
    try {
      const history = data.chatHistory || [];
      const { text, history: updatedHistory } = await geminiService.sendChatMessage(
        message, 
        history,
        upstreamNodes.map(n => `[Source: ${n.label}]\n${n.output}`).join('\n\n---\n\n')
      );
      onUpdate(node.id, { 
        chatHistory: updatedHistory,
        output: text,
        runState: RunState.RAN,
        isDirty: false
      });
    } catch (error) {
      console.error(error);
      onUpdate(node.id, { runState: RunState.ERROR });
    } finally {
      setIsChatting(false);
    }
  };

  const handleFinalize = () => {
    onUpdate(node.id, { 
      isChatMode: false,
      isFinalized: true
    });
  };

  const toggleChatMode = () => {
    if (!canUseChat) return;
    const isTurningOn = !data.isChatMode;
    onUpdate(node.id, { isChatMode: isTurningOn });
    if (isTurningOn) {
      setChatInput(data.prompt || '');
    }
  };

  const insertAtCursor = (text: string) => {
    if (!textareaRef.current) return;
    const { selectionStart, selectionEnd } = textareaRef.current;
    const currentVal = isDataNode || isStickyNode ? data.input : data.prompt;
    const newVal = currentVal.substring(0, selectionStart) + text + currentVal.substring(selectionEnd);
    
    const field = isDataNode || isStickyNode ? 'input' : 'prompt';
    onUpdate(node.id, { [field]: newVal, isDirty: true });
    setIsRecallOpen(false);

    // Maintain focus and set cursor position after the inserted text
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPos = selectionStart + text.length;
        textareaRef.current.setSelectionRange(newPos, newPos);
      }
    }, 0);
  };

  return (
    <div className="w-[450px] bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-[-10px_0_40px_rgba(0,0,0,0.5)] overflow-hidden z-30 animate-in slide-in-from-right duration-300">
      <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold flex items-center gap-2 text-white">
            {isDataNode && <Database size={18} className="text-blue-400" />}
            {isAiPromptNode && <Sparkles size={18} className="text-purple-400" />}
            {isRefactorNode && <RefreshCcw size={18} className="text-emerald-400" />}
            {isStickyNode && <StickyIcon size={18} className="text-amber-400" />}
            {isDataNode ? 'Data Provider' : isStickyNode ? 'Sticky Note' : isRefactorNode ? 'Code Refactor' : 'AI Prompt'}
          </h2>
          <span className="text-[10px] font-bold text-slate-500 font-mono tracking-widest uppercase mt-1">Ref ID: {node.id}</span>
        </div>
        <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-800 text-slate-500 hover:text-white transition-all">
          <CloseIcon size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
        {canUseChat && (
          <section className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${data.isChatMode ? 'bg-purple-600/20 text-purple-400' : 'bg-slate-800 text-slate-500'}`}>
                <MessageCircle size={18} />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-200">Interactive Chat Agent</span>
                <span className="text-[9px] text-slate-500 uppercase tracking-wider">Refine outputs with turns</span>
              </div>
            </div>
            <button 
              onClick={toggleChatMode}
              className={`w-12 h-6 rounded-full transition-all relative ${data.isChatMode ? 'bg-purple-600' : 'bg-slate-700'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${data.isChatMode ? 'left-7' : 'left-1'}`} />
            </button>
          </section>
        )}

        {!activeChatMode ? (
          <>
            {/* Visual Customization (Icons & Glow) - Collapsible */}
            {!isStickyNode && (
              <section className="bg-slate-800/20 p-4 rounded-2xl border border-slate-800 transition-all">
                <button 
                  onClick={() => setIsVisualExpanded(!isVisualExpanded)}
                  className="w-full flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-1 h-4 bg-purple-500 rounded-full" />
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] group-hover:text-slate-300 transition-colors cursor-pointer">Visual Character</label>
                  </div>
                  {isVisualExpanded ? <ChevronDown size={14} className="text-slate-500" /> : <ChevronRight size={14} className="text-slate-500" />}
                </button>
                
                {isVisualExpanded && (
                  <div className="mt-4 space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-2 uppercase tracking-tighter">Choose Icon</span>
                      <div className="flex flex-wrap gap-2">
                        {ICONS.map((icon) => (
                          <button
                            key={icon.name}
                            onClick={() => onUpdate(node.id, { icon: icon.name })}
                            className={`p-2.5 rounded-xl border-2 transition-all hover:scale-105 ${
                              data.icon === icon.name ? 'border-purple-500 bg-purple-500/10 text-purple-400' : 'border-slate-800 bg-slate-900 text-slate-500 hover:border-slate-700'
                            }`}
                          >
                            <icon.component size={16} />
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-2 uppercase tracking-tighter">Glow Aura</span>
                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => onUpdate(node.id, { glowColor: undefined, glowIntensity: 0 })}
                          className={`w-8 h-8 rounded-full border-2 border-slate-700 bg-slate-900 flex items-center justify-center text-[10px] text-slate-500 font-bold ${!data.glowColor || data.glowIntensity === 0 ? 'ring-2 ring-white/40' : ''}`}
                        >
                          OFF
                        </button>
                        {GLOW_COLORS.map((color) => (
                          <button
                            key={color.value}
                            onClick={() => onUpdate(node.id, { glowColor: color.value, glowIntensity: data.glowIntensity || 2 })}
                            className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${
                              data.glowColor === color.value && data.glowIntensity !== 0 ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                            }`}
                            style={{ backgroundColor: color.value, boxShadow: data.glowColor === color.value && data.glowIntensity !== 0 ? `0 0 10px ${color.value}` : 'none' }}
                          />
                        ))}
                      </div>
                    </div>

                    {data.glowColor && (
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] text-slate-400 uppercase tracking-tighter">Intensity (4 Levels)</span>
                          <span className="text-[10px] text-purple-400 font-mono font-bold">
                            {data.glowIntensity === 0 ? 'OFF' : `LVL ${data.glowIntensity}`}
                          </span>
                        </div>
                        <input 
                          type="range" min="0" max="3" step="1"
                          value={data.glowIntensity ?? 0}
                          onChange={(e) => onUpdate(node.id, { glowIntensity: parseInt(e.target.value) })}
                          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                        />
                        <div className="flex justify-between mt-1 px-1">
                          <span className="text-[8px] text-slate-600 font-bold">OFF</span>
                          <span className="text-[8px] text-slate-600 font-bold">MIN</span>
                          <span className="text-[8px] text-slate-600 font-bold">MID</span>
                          <span className="text-[8px] text-slate-600 font-bold">MAX</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </section>
            )}

            {isStickyNode && (
              <section className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="w-1 h-4 bg-amber-500 rounded-full" />
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Note Aesthetics</label>
                </div>
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => onUpdate(node.id, { bgColor: color.value })}
                      className={`w-8 h-8 rounded-lg border-2 transition-all hover:scale-110 active:scale-95 ${
                        data.bgColor === color.value ? 'border-white' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: color.value }}
                    />
                  ))}
                </div>
              </section>
            )}

            {!isStickyNode && (
              <section className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="w-1 h-4 bg-blue-500 rounded-full" />
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Step Label</label>
                </div>
                <input
                  type="text"
                  value={data.label}
                  onChange={(e) => onUpdate(node.id, { label: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium text-slate-200"
                  placeholder="e.g. 'Summarization Logic'..."
                />
              </section>
            )}

            {/* Node Comments Section - Now below the Step Label */}
            <section className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-1 h-4 bg-slate-600 rounded-full" />
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Internal Annotations</label>
              </div>
              <div className="relative group">
                <div className="absolute left-4 top-4 text-slate-600 group-focus-within:text-blue-500 transition-colors">
                  <MessageSquareText size={16} />
                </div>
                <textarea
                  value={data.comment || ''}
                  onChange={(e) => onUpdate(node.id, { comment: e.target.value })}
                  placeholder="Add private notes or comments about this node's purpose..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-12 pr-4 py-4 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/50 min-h-[80px] text-slate-400 placeholder:text-slate-700 transition-all italic"
                />
              </div>
            </section>

            <section className="space-y-4 relative">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-1 h-4 rounded-full ${isDataNode ? 'bg-blue-500' : isStickyNode ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
                    {isDataNode ? 'Payload Content' : isStickyNode ? 'Markdown Content' : 'Directives (Prompt)'}
                  </label>
                </div>
                
                {/* Recall UI */}
                {upstreamNodes.length > 0 && (
                  <div className="relative">
                    <button 
                      onClick={() => setIsRecallOpen(!isRecallOpen)}
                      className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700 transition-all active:scale-95"
                    >
                      <History size={12} className="text-amber-500" />
                      <span className="text-[10px] font-bold uppercase tracking-widest">Recall</span>
                      <ChevronDown size={10} className={`transition-transform duration-200 ${isRecallOpen ? 'rotate-180' : ''}`} />
                    </button>
                    
                    {isRecallOpen && (
                      <div className="absolute right-0 top-full mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-[0_10px_30px_rgba(0,0,0,0.5)] z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
                        <div className="p-3 border-b border-slate-800 bg-slate-800/50">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Predecessors</span>
                        </div>
                        <div className="max-h-60 overflow-y-auto custom-scrollbar">
                          {upstreamNodes.map((p) => (
                            <button
                              key={p.id}
                              onClick={() => insertAtCursor(p.output)}
                              className="w-full text-left p-3 hover:bg-blue-600/10 border-b border-slate-800/50 last:border-none group transition-colors"
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-[11px] font-bold text-slate-200 group-hover:text-blue-400 transition-colors">{p.label}</span>
                                <span className="text-[9px] text-slate-500 font-mono">ID: {p.id.slice(-4)}</span>
                              </div>
                              <p className="text-[10px] text-slate-500 line-clamp-2 italic leading-relaxed">
                                {p.output ? p.output.substring(0, 100) : 'No output generated...'}
                              </p>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              <textarea
                ref={textareaRef}
                rows={isStickyNode ? 12 : 8}
                value={isDataNode || isStickyNode ? data.input : data.prompt}
                onChange={(e) => {
                  const field = isDataNode || isStickyNode ? 'input' : 'prompt';
                  onUpdate(node.id, { [field]: e.target.value, isDirty: true });
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono resize-none leading-relaxed text-slate-300 custom-scrollbar shadow-inner"
                placeholder={isStickyNode ? "Enter Markdown here..." : isDataNode ? "Enter data context..." : "Enter logical instructions..."}
              />
            </section>

            {data.output && !isStickyNode && (
              <section className="space-y-4 pb-4">
                <div className="flex items-center gap-2">
                  <span className="w-1 h-4 bg-slate-600 rounded-full" />
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Final Output</label>
                </div>
                <div className="bg-black/40 rounded-2xl p-4 border border-slate-800/50 text-[11px] font-mono text-slate-400 leading-relaxed max-h-[250px] overflow-y-auto custom-scrollbar">
                  <div className="whitespace-pre-wrap">{data.output}</div>
                </div>
              </section>
            )}
          </>
        ) : (
          <div className="flex flex-col h-[calc(100vh-250px)]">
            <div className="flex-1 overflow-y-auto space-y-4 p-2 custom-scrollbar">
              {(data.chatHistory || []).length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-40">
                  <MessageSquare size={40} className="mb-4 text-purple-400" />
                  <p className="text-xs font-bold uppercase tracking-widest">No conversation yet</p>
                  <p className="text-[10px] mt-2">Start chatting to refine the output of this node using the upstream context.</p>
                </div>
              )}
              {data.chatHistory?.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white rounded-tr-none' 
                      : 'bg-slate-800 text-slate-300 border border-slate-700 rounded-tl-none'
                  }`}>
                    <div className="flex items-center gap-2 mb-1.5 opacity-60 text-[9px] uppercase font-bold tracking-tighter">
                      {msg.role === 'user' ? 'You' : 'Gemini'}
                    </div>
                    <div className="whitespace-pre-wrap">{msg.parts[0]?.text}</div>
                  </div>
                </div>
              ))}
              {isChatting && (
                <div className="flex justify-start">
                  <div className="bg-slate-800 text-slate-300 border border-slate-700 rounded-2xl rounded-tl-none px-4 py-3 text-xs flex items-center gap-3 shadow-md animate-in fade-in slide-in-from-bottom-2">
                    <RefreshCcw size={14} className="animate-spin text-purple-400" />
                    <span className="animate-pulse">Thinking...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} className="h-4 w-full flex-shrink-0" />
            </div>

            <div className="mt-4 space-y-3">
              <div className="relative">
                <textarea
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendChat();
                    }
                  }}
                  placeholder="Ask for changes or refinements..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-4 pr-12 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500/50 font-sans resize-none h-24 custom-scrollbar"
                />
                <button
                  onClick={handleSendChat}
                  disabled={isChatting || !chatInput.trim()}
                  className="absolute bottom-4 right-4 p-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white rounded-xl transition-all"
                >
                  <Send size={16} />
                </button>
              </div>
              <button
                onClick={handleFinalize}
                disabled={(data.chatHistory || []).length === 0}
                className="w-full py-3 bg-emerald-600/10 hover:bg-emerald-600 border border-emerald-500/20 text-emerald-400 hover:text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-30"
              >
                <CheckCircle size={14} />
                Finalize & Update Output
              </button>
            </div>
          </div>
        )}
      </div>

      <div className={`p-6 bg-slate-900 border-t border-slate-800 grid ${isStickyNode || activeChatMode ? 'grid-cols-1' : 'grid-cols-2'} gap-4 sticky bottom-0 z-10 backdrop-blur-xl`}>
        {!isStickyNode && !activeChatMode && (
          <button
            onClick={() => onRun(node.id)}
            disabled={data.runState === RunState.RUNNING}
            className={`flex items-center justify-center gap-3 font-bold py-3.5 rounded-2xl transition-all shadow-lg active:scale-[0.98] disabled:scale-100 ${
              isDataNode 
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 shadow-slate-900/20' 
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/20'
            }`}
          >
            {data.runState === RunState.RUNNING ? (
              <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <>
                {isDataNode ? <ArrowDownToLine size={18} /> : <Play size={18} fill="currentColor" />}
                <span className="text-sm">{isDataNode ? 'Publish Data' : 'Run Logic'}</span>
              </>
            )}
          </button>
        )}
        <button
          onClick={() => onDelete(node.id)}
          className={`flex items-center justify-center gap-3 bg-red-950/20 hover:bg-red-900/30 text-red-400 border border-red-900/20 py-3.5 rounded-2xl transition-all active:scale-[0.98] ${isStickyNode || activeChatMode ? 'w-full' : ''}`}
        >
          <Trash2 size={18} />
          <span className="text-sm font-bold">Delete {isStickyNode ? 'Note' : 'Node'}</span>
        </button>
      </div>
    </div>
  );
};

export default NodeEditor;
