# API & Database Migration Specification

This document outlines the architecture for migrating the **Modular AI Orchestration Canvas** from browser `localStorage` to a centralized MongoDB database and Node.js API.

## 1. Data Models (TypeScript / Mongoose)

### User Model
```typescript
interface UserDocument {
  _id: string;          // MongoDB ObjectId
  email: string;        // Unique
  passwordHash: string; // BCrypt hashed
  lastUsedWorkflowId?: string; // Reference to Workflows._id
  createdAt: Date;
}
```

### Workflow Model
```typescript
interface WorkflowDocument {
  _id: string;          // MongoDB ObjectId
  userId: string;       // Reference to User._id
  name: string;         // e.g. "Untitled Workflow"
  lastModified: Date;
  state: {
    nodes: any[];       // React Flow Node objects
    edges: any[];       // React Flow Edge objects
    activeBranches: Record<string, string>;
    globalVariables: Record<string, any>;
  };
}
```

## 2. API Endpoints

### Authentication
| Endpoint | Method | Payload | Output |
| :--- | :--- | :--- | :--- |
| `/api/auth/signup` | `POST` | `{ email, password }` | `{ user: UserMetadata, token: string }` |
| `/api/auth/login` | `POST` | `{ email, password }` | `{ user: UserMetadata, token: string }` |

### Workflows (CRUD)
| Endpoint | Method | Payload | Output | Description |
| :--- | :--- | :--- | :--- | :--- |
| `/api/workflows` | `GET` | None | `WorkflowMetadata[]` | Returns index for current user. |
| `/api/workflows` | `POST` | `{ name: string }` | `WorkflowDocument` | Creates a new workflow. |
| `/api/workflows/:id` | `GET` | None | `WorkflowDocument` | Fetches full graph state. |
| `/api/workflows/:id` | `PUT` | `Partial<WorkflowDocument>` | `{ success: boolean }` | Autosave/Update logic. |
| `/api/workflows/:id` | `DELETE` | None | `{ success: boolean }` | Removes workflow. |

## 3. Storage Mapping (Local -> Remote)

| LocalStorage Key | MongoDB Equivalent |
| :--- | :--- |
| `modular_ai_canvas_users` | `Users` Collection (individual docs) |
| `user_{email}_modular_ai_canvas_index` | `Workflows` Collection (query by `userId`) |
| `user_{email}_workflow_{id}` | `Workflows.state` field |
| `user_{email}_modular_ai_canvas_last_used`| `Users.lastUsedWorkflowId` field |

## 4. Implementation Notes

1.  **JWT Authentication**: Replace `modular_ai_canvas_session` with a JWT stored in an HttpOnly cookie or `localStorage`.
2.  **Atomic Updates**: Use MongoDB's `$set` operator for the 1.5s autosave pulse to avoid overwriting the entire document if only one node changed.
3.  **Unique Constraints**: The `label` uniqueness check currently done on the frontend in `NodeEditor.tsx` should remain there for UX, but be validated by a pre-save hook in the database.
4.  **Isolation**: Multi-user isolation is enforced by the `userId` field on every workflow document. No query should be executed without a `where: { userId: current_user_id }` filter.