# User Flows: Modular AI Orchestration Canvas

## 1. Multi-User Authentication & Isolation
- **Signup Flow**:
  1. User clicks "Login / Signup" in the top panel.
  2. Switches to "Sign Up Now".
  3. Enters Email and Password.
  4. App validates if user exists in `modular_ai_canvas_users` (localStorage).
  5. On success, a new user is created and logged in.
  6. **Isolation**: All subsequent storage keys are prefixed with `user_{sanitized_email}_`.
- **Login Flow**:
  1. User enters credentials.
  2. App checks `modular_ai_canvas_users`.
  3. If "Remember me" is checked, session persists in `localStorage` for 30 days. Otherwise, `sessionStorage`.
  4. App loads the `LAST_USED_KEY` specific to that user and restores the last active workflow.
- **Logout Flow**:
  1. User clicks "Logout".
  2. `CURRENT_SESSION_KEY` is removed.
  3. App state resets to default "Guest" view.

## 2. Workflow Lifecycle
- **Creation**:
  1. User clicks "Workflow Library" (folder icon).
  2. Clicks "New Empty Workflow".
  3. App generates a unique `wf-` ID and initial data node.
- **Management**:
  1. **Rename**: User clicks the pencil icon next to the workflow name in the top-left panel.
  2. **Fork**: User clicks the "Fork" icon. This creates a duplicate of the current state under a new ID and name.
  3. **Delete**: In the Workflow Library, clicking the trash icon removes the specific key from `localStorage` and updates the index.
- **Persistence**:
  1. Every 1.5s after a change, the app auto-saves to `user_{email}_workflow_{id}`.

## 3. Node-Based Logic Design
- **Creation**:
  1. User uses Toolbox (top-left) or Drag-from-Handle + Modifier Key:
     - **Shift** for Data Source
     - **Ctrl/Cmd** for Transformation Step
     - **Alt/Opt** for Code Block
     - **Shift+Alt / Shift+Opt** for API Integration
- **Interpolation & Recall**:
  1. User edits a node field (e.g., Prompt).
  2. User clicks "Recall" to see ancestors.
  3. Clicking an ancestor with "Variable" checked inserts `{ $("Label").output }`.
  4. The "Resolved Preview" updates in real-time to show what the logic will evaluate to.
- **Execution**:
  1. User clicks "Run Logic" / "Execute JS".
  2. App resolves interpolations, gathers context, and calls Gemini API or executes local JS.
  3. Output is stored and propagated to downstream children.