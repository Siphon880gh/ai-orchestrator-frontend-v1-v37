# Modular AI Orchestration Canvas

A visual IDE for AI workflow design, allowing users to map, execute, and refactor complex logic using a dynamic branching flowchart. This tool enables modular prompt engineering where AI responses can serve as context for subsequent logical steps.

- **Visual Orchestration**: Powered by React Flow for a seamless drag-and-drop experience.
- **AI-Native**: Deeply integrated with Google Gemini (Pro for logic, Flash for summarization).
- **Persistent Workspace**: Full support for multiple workflows, undo/redo history, and local storage persistence.
- **Multi-User Isolation**: Isolated storage namespaces based on user login.
- **Modular Data Flow**: Nodes inherit context from all connected upstream parents.

## 🛠 Testing & Coverage

The project includes a multi-layered testing strategy to ensure data reliability and logic correctness.

### Automated Unit Tests
We use **Vitest** for testing core logic such as the interpolation engine and graph utilities.
- **Run tests**: `npm test`
- **Watch mode**: `npm run test:watch`
- **Generate coverage**: `npm run test:coverage`

### Browser Simulation (Integration)
A dedicated simulation page is available for manual and automated E2E workflow testing. This bypasses the need for complex Selenium setups by providing a scriptable React environment directly in the browser.
- **Access**: Navigate to `/tests/simulation.html` in your browser.
- **Features**: User switching, persistence verification, and auto-test sequences for data isolation.

### CI/CD Pipeline
Tests are automatically run on every push to `main` via GitHub Actions. The build will fail if code coverage falls below the defined thresholds:
- Statements: 80%
- Branches: 75%
- Functions: 85%

### Uncovered Areas (TODO)
- [ ] Gemini API streaming error states (requires stable mock of `generateContentStream`).
- [ ] Node Resizer edge cases in `StickyNoteNode`.
- [ ] Multi-touch gesture support in React Flow.

Refer to [context-test-plan.md](./context-test-plan.md) for the full testing strategy.