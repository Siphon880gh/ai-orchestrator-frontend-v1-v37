
import { NodeType } from '../types';

export interface ModifierMapping {
  type: NodeType;
  label: string;
}

/**
 * Mappings for creating nodes via drag-and-release on the canvas.
 */
export const NODE_CREATION_MAPPINGS = {
  // Key '2'
  TWO_KEY: {
    type: NodeType.API_REQUEST,
    label: 'New API Request',
  },
  // Key '1'
  CODE_KEY: {
    type: NodeType.CODE,
    label: 'New JS Logic',
  },
  // SHIFT + (CTRL or CMD)
  COMBINED: {
    type: NodeType.AI_PROMPT,
    label: 'New AI Logic',
  },
  // SHIFT only
  SHIFT: {
    type: NodeType.DATA_INPUT,
    label: 'New Data Source',
  },
  // CTRL or CMD only
  MODIFIER: {
    type: NodeType.REFACTOR,
    label: 'New Transformation',
  },
  // No modifier keys
  DEFAULT: {
    type: NodeType.AI_PROMPT,
    label: 'New AI Logic',
  },
};
