
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

export class GeminiService {
  /**
   * Run a logic prompt against the Gemini model with optional context from previous nodes.
   */
  async runPrompt(prompt: string, context?: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const fullPrompt = context 
        ? `Context Information:\n${context}\n\nTask:\n${prompt}`
        : prompt;

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: fullPrompt,
      });

      return response.text || "No response generated.";
    } catch (error) {
      console.error("Gemini Error:", error);
      throw error;
    }
  }

  /**
   * Interactive Chat session for refined logic.
   */
  async sendChatMessage(message: string, history: ChatMessage[], context?: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const chat = ai.chats.create({
        model: 'gemini-3-pro-preview',
        config: {
          systemInstruction: context ? `CONTEXT:\n${context}\n\nYou are a specialized AI logic component in a larger workflow. Assist the user in refining the output for this specific step.` : "You are a specialized AI logic component.",
        },
        // We pass the history as is. The SDK handles formatting if compliant.
        history: history as any,
      });

      const response = await chat.sendMessage({ message });
      
      return {
        text: response.text || "No response.",
        // Return the updated history from the chat object
        history: chat.history as unknown as ChatMessage[]
      };
    } catch (error) {
      console.error("Gemini Chat Error:", error);
      throw error;
    }
  }

  /**
   * Summarize the entire workflow logic and suggest automation improvements.
   */
  async summarizeWorkflow(workflowJson: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this workflow JSON and provide a high-level summary of the logic paths and n8n automation suggestions:\n\n${workflowJson}`,
      });
      return response.text || "Failed to summarize.";
    } catch (error) {
      console.error("Gemini Summarization Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
