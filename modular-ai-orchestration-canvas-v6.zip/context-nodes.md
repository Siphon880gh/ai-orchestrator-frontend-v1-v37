# Context: Node Architecture & UI

*Note: Line numbers are referenced approximately.*

## Node Types (`types.ts`)
1. **`aiPrompt`**: Uses the `gemini-3-pro-preview` model to process context.
2. **`dataInput`**: Holds static text or JSON. Its `output` is always equal to its `input`.
3. **`refactor`**: Similar to AI nodes but visually distinct for "patching" logic.
4. **`stickyNote`**: Non-executable documentation nodes with Markdown support.

## Visual Design
The UI follows a strict "Dark Slate" aesthetic defined in `index.html`. 
- Nodes use dynamic border colors in `CustomNode.tsx` to reflect their `RunState` (Running = Blue, Ran = Green, Error = Red).
- **Z-Index**: Sticky notes are forced to `zIndex: -10` to act as background annotations.

## The Node Editor (`components/NodeEditor.tsx`)
The sidebar provides deep configuration:
- **Directives**: Logic nodes edit the `prompt` field.
- **Literal Payload**: Data nodes edit the `input` field.
- **Context Preview**: Displays a read-only snippet of what context this node is currently receiving from parents.

## Custom Edges (`components/ButtonEdge.tsx`)
Instead of standard lines, we use a custom edge that renders a "Delete" button (`X`) on hover. This is implemented using React Flow's `EdgeLabelRenderer`.