
import React, { memo } from 'react';
import { NodeProps, NodeResizer } from 'reactflow';
import { CanvasNodeData } from '../types';
import { marked } from 'marked';
import { GripHorizontal } from 'lucide-react';

const StickyNoteNode = ({ data, selected }: NodeProps<CanvasNodeData>) => {
  // marked.parse returns a string (HTML)
  const htmlContent = marked.parse(data.input || '*Empty sticky note. Click to edit.*');

  // Default color if none provided
  const bgColor = data.bgColor || 'rgba(30, 41, 59, 0.4)';

  return (
    <div 
      className={`w-full h-full p-6 border-2 transition-all duration-200 backdrop-blur-sm shadow-xl flex flex-col ${
        selected ? 'border-white/40 ring-2 ring-white/10' : 'border-slate-700/50'
      } rounded-xl group`}
      style={{ 
        backgroundColor: bgColor,
        minWidth: '200px',
        minHeight: '100px'
      }}
    >
      <NodeResizer 
        color="#3b82f6" 
        isVisible={selected} 
        minWidth={200} 
        minHeight={100}
        handleStyle={{ width: 8, height: 8, borderRadius: 2 }}
      />
      
      {/* Drag handle area */}
      <div className="flex items-center justify-between mb-3 opacity-50 select-none flex-shrink-0 cursor-grab active:cursor-grabbing">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-white/50" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/70">Documentation Note</span>
        </div>
        <GripHorizontal size={14} className="text-white/30 group-hover:text-white/70 transition-colors" />
      </div>
      
      <div 
        className="text-sm text-slate-200 markdown-content overflow-auto flex-1 custom-scrollbar pointer-events-none"
        dangerouslySetInnerHTML={{ __html: htmlContent }}
      />
    </div>
  );
};

export default memo(StickyNoteNode);
