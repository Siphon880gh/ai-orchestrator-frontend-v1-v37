# Context: Runtime & State Management

*Note: Line numbers are referenced approximately.*

## State Management (`App.tsx`)
The application manages three primary state buckets:
- `nodes` & `edges`: The React Flow state representing the current graph.
- `history` & `future`: Arrays of graph snapshots used for the custom Undo/Redo implementation.
- `workflows`: Metadata index for saved projects.

### History Implementation
Near the middle of `App.tsx`, the `recordHistory` function captures deep clones of the current state. The `undo` and `redo` functions manipulate these stacks while using an `isInternalChange` ref to prevent feedback loops.

## Node Execution Logic
The `runNode` function (found in the lower half of `App.tsx`) is the heart of the orchestrator:
1. It identifies all edges where `target === id`.
2. It fetches the `source` nodes for those edges.
3. It concatenates the source `output` (or `input` for data nodes) into a single "Upstream Context" string.
4. It triggers the Gemini API via `geminiService.runPrompt`.

## Persistence Strategy
Workflows are indexed in `localStorage` under `modular_ai_canvas_index`. Individual workflow data is stored as JSON strings keyed by a unique ID (e.g., `modular_ai_canvas_workflow_wf-123`).
- **Autosave**: A `useEffect` in `App.tsx` triggers a save 1.5 seconds after any change, with a visual "Syncing..." indicator.

## Layouting
`utils/layout.ts` wraps the Dagre library. It calculates X/Y positions based on a "Top-to-Bottom" (TB) rank direction, ensuring complex branches are readable.