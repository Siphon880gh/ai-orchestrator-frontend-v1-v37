import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import SimulationDashboard from './components/SimulationDashboard.tsx';

// Global handler to suppress benign ResizeObserver loop limit errors
if (typeof window !== 'undefined') {
  window.addEventListener('error', (e) => {
    const isResizeObserverError = 
      e.message === 'ResizeObserver loop completed with undelivered notifications.' || 
      e.message === 'ResizeObserver loop limit exceeded';
      
    if (isResizeObserverError) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }
  });
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

// Environment Switcher Logic (Virtual Routing)
const mode = localStorage.getItem('env_mode');
const isSimulation = mode === 'test';

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    {isSimulation ? <SimulationDashboard /> : <App />}
  </React.StrictMode>
);