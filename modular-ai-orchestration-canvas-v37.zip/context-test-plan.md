# Test Plan: Modular AI Orchestration Canvas

## 1. Scope & Priorities
- **High Priority**:
  - Multi-user data isolation (User A cannot see User B's workflows).
  - Workflow persistence (Autosave and manual load).
  - Logic Interpolation (Ensuring `{}` expressions evaluate correctly).
- **Medium Priority**:
  - Node creation shortcuts and UI responsiveness.
  - Interactive Chat Agent (Gemini API integration).
  - Import/Export functionality.

## 2. Testing Methodology
- **Unit Testing**: 
  - Using **Vitest** for testing utility functions (layout, interpolation logic).
- **Integration Testing**:
  - **Browser Simulator**: A dedicated `tests/simulation.html` page to perform manual/automated UI flow simulations in the real browser environment.
- **End-to-End (E2E)**:
  - Manual validation of Gemini API responses and UI transitions.

## 3. Test Cases (Multi-User Simulation)
1. **User Isolation**:
   - Register User A, create Workflow "Alpha".
   - Logout User A.
   - Register User B, create Workflow "Beta".
   - Verify User B's library only contains "Beta".
   - Login User A, verify library only contains "Alpha".
2. **Persistence**:
   - Create Workflow "Test", add 3 nodes.
   - Refresh page.
   - Verify "Test" loads with all nodes in correct positions.
3. **Interpolation**:
   - Create Data node "Value" with input "42".
   - Create AI node with prompt "The answer is { $('Value').output }".
   - Verify Resolved Preview shows "The answer is 42".

## 4. Coverage Goals
- **Statements**: >80%
- **Branches**: >75%
- **Functions**: >85%

## 5. Tooling
- **Testing Framework**: Vitest
- **Simulation**: Custom React-based Sandbox (`tests/simulation.tsx`)
- **CI**: GitHub Actions (configured to run `npm test` and check coverage).