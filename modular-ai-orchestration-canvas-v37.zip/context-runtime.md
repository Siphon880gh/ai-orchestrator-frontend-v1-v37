
# Context: Runtime & State Management

## State Management (`App.tsx`)
The app uses a unified state for `nodes`, `edges`, and `globalVariables`.
- **Global Variables**: An object persisted in the `WorkflowState`. It is modified by **Code Nodes** and consumed via curly brace interpolation `{...}`.
- **Unique Naming**: A `getUniqueLabel` utility ensures every new node has a distinct name by checking existing labels and incrementing a numeric suffix if necessary.
- **Undo/Redo**: Controlled via `history` and `future` stacks. `recordHistory` snapshots the entire graph including global variables.
- **Autosave**: Persists state to `localStorage` every 1.5s after any change.

## Node Execution Logic (`runNode` in `App.tsx`)
1. **Interpolation Resolution**: Before running, nodes with text fields (Prompt, Input, URL, Payload) pass their content through `resolveInterpolation`. This evaluates anything inside curly braces as JavaScript.
   - **The $ Utility**: A specialized `$(label)` function is injected into the evaluation context. It allows users to reference any node's output by its visual label: `{ $("My Node").output }`. **Lookup is case-insensitive**. If a node with the specified label is not found, it returns `""` (an empty string).
   - **JSON Support**: If a node's output is valid JSON, the `$` utility automatically parses it, allowing for nested access: `{ $("My API").output.user.name }`.
2. **Context Aggregation**: Gathers `output` from all source nodes.
3. **Node-Specific Logic**:
   - **Code Nodes**: Injected with `context`, `upstream`, and `global`. Changes to the `global` object are synced back to the App state.
   - **API Nodes**: Perform `fetch` using interpolated URLs and Payloads.
   - **AI Nodes**: Send interpolated prompts + aggregated context to Gemini.

## Label Validation Logic
The **Node Editor** maintains local state for label editing. When a user types a name:
- The system checks all *other* nodes in the current workflow.
- If the name matches an existing label (case-insensitive), an `AlertTriangle` warning appears, and the underlying node data is **not** updated.
- Once a unique name is entered, the validation error clears and the node data is updated via `onUpdate`.

## Persistence & Storage Schema
Updated to include global variables:
1. **Workflow State (`user_${email}_workflow_${id}`)**: 
   - Stores the `WorkflowState` object which now includes a `globalVariables` map.
