# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Multi-User Authentication**, **Workflow Management**, and a robust **Interpolation Engine** for cross-node state persistence.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Testing**: Vitest + Custom Browser Simulation

## File Tree & Roles
- `App.tsx`: Core hub managing auth, graph state, and interpolation logic.
- `types.ts`: Shared data models.
- `components/NodeEditor.tsx`: Configuration UI with interpolation previews.
- `tests/simulation.html`: Integration test sandbox for multi-user flows.
- `tests/workflow.test.ts`: Unit tests for critical path logic.
- `api-migration-specification.md`: Roadmap for transitioning from LocalStorage to MongoDB.

## Quality Assurance
The codebase maintains high stability through:
1. **User Flow Documentation**: Detailed in `context-user-flows.md`.
2. **Comprehensive Test Plan**: Detailed in `context-test-plan.md`.
3. **Automated Coverage**: Enforced via Vitest in CI/CD.
4. **Browser Simulation**: Validates persistence and multi-user isolation in real-world scenarios.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.