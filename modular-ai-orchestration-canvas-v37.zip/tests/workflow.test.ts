import { describe, it, expect } from 'vitest';

/**
 * Mocking the interpolation logic from App.tsx (conceptually)
 * In a real production environment, we would export these utilities from a separate file.
 */
const resolveInterpolation = (text: string, globalVariables: Record<string, any>, nodes: any[]) => {
    if (!text) return '';

    const $ = (label: string) => {
      const targetNode = nodes.find(n => n.data.label.toLowerCase() === label.toLowerCase());
      if (!targetNode) return "";
      
      const rawOutput = targetNode.data.output || targetNode.data.input || '';
      let parsedOutput = rawOutput;
      try {
        if (typeof rawOutput === 'string' && (rawOutput.trim().startsWith('{') || rawOutput.trim().startsWith('['))) {
            parsedOutput = JSON.parse(rawOutput);
        }
      } catch (e) { }
      return { output: parsedOutput };
    };

    return text.replace(/\{(.+?)\}/g, (_, code) => {
      try {
        const fn = new Function('global', '$', `return (${code})`);
        const val = fn(globalVariables, $);
        return val !== undefined ? String(val) : '';
      } catch (e) {
        return `{Error: ${e instanceof Error ? e.message : 'Invalid Expression'}}`;
      }
    });
};

describe('Interpolation Logic', () => {
    const mockNodes = [
        { data: { label: 'User Name', output: 'Alice' } },
        { data: { label: 'Settings', output: '{"theme": "dark", "count": 10}' } }
    ];
    const mockGlobals = { api_key: 'sk-123' };

    it('should resolve global variables', () => {
        const input = "Key: {global.api_key}";
        const output = resolveInterpolation(input, mockGlobals, mockNodes);
        expect(output).toBe("Key: sk-123");
    });

    it('should resolve cross-node references via $()', () => {
        const input = "Hello { $('User Name').output }";
        const output = resolveInterpolation(input, mockGlobals, mockNodes);
        expect(output).toBe("Hello Alice");
    });

    it('should resolve JSON paths from cross-node references', () => {
        const input = "Theme: { $('Settings').output.theme }";
        const output = resolveInterpolation(input, mockGlobals, mockNodes);
        expect(output).toBe("Theme: dark");
    });

    it('should handle missing nodes gracefully', () => {
        const input = "Ref: { $('NonExistent').output }";
        const output = resolveInterpolation(input, mockGlobals, mockNodes);
        expect(output).toBe("Ref: ");
    });

    it('should handle mathematical expressions', () => {
        const input = "Result: { 2 + 2 * 10 }";
        const output = resolveInterpolation(input, mockGlobals, mockNodes);
        expect(output).toBe("Result: 22");
    });
});