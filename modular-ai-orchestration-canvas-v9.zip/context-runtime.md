# Context: Runtime & State Management

*Note: Approximate location references are intentional.*

## State Management (`App.tsx`)
The app uses a unified state for `nodes` and `edges`. 
- **Undo/Redo**: Controlled via `history` and `future` stacks. `recordHistory` clones the current graph state.
- **Autosave**: Persists the graph to `localStorage` every 1.5s after changes.

## Node Execution Logic
Found in the lower half of `App.tsx` within the `runNode` function:
1. Gathers `output` from all source nodes connected to the target.
2. Passes this combined string as "Upstream Context" to Gemini.

## Chat Agent Logic (`services/geminiService.ts`)
The `GeminiService` class (around the middle of the file) now supports stateful refinement:
- `sendChatMessage`: Uses `ai.chats.create` with a provided history and context-aware `systemInstruction`.
- It leverages the `gemini-3-pro-preview` model for advanced reasoning.

## Persistence
- **Workflow Index**: Stored under `modular_ai_canvas_index`.
- **Node Data**: Fields like `chatHistory`, `isChatMode`, and `isFinalized` are stored directly within the node's `data` object in the graph JSON. This ensures that a refinement session can be resumed across browser reloads.

## Context Aggregation
Nodes do not just receive the prompt; they receive a structured snapshot of their parents' outputs. In Chat Mode, this context is provided as a System Instruction to ensure the AI "knows" what data it is helping the user process.