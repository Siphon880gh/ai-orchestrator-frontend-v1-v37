
import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { CanvasNodeData, NodeType, RunState } from '../types';
import { Brain, FileText, RefreshCw, AlertCircle, CheckCircle2, Play } from 'lucide-react';

const CustomNode = ({ data, selected }: NodeProps<CanvasNodeData>) => {
  const isAi = data.type === NodeType.AI_PROMPT;
  const isData = data.type === NodeType.DATA_INPUT;
  const isRefactor = data.type === NodeType.REFACTOR;

  const getBorderColor = () => {
    if (data.runState === RunState.RUNNING) return 'border-blue-500 shadow-lg shadow-blue-500/20';
    if (data.runState === RunState.ERROR) return 'border-red-500 shadow-lg shadow-red-500/20';
    if (data.runState === RunState.RAN) return 'border-green-500/50';
    return selected ? 'border-blue-400' : 'border-slate-700';
  };

  const getShapeClasses = () => {
    switch (data.shape) {
      case 'rounded': return 'rounded-2xl';
      case 'diamond': return 'rotate-45 p-6'; // Diamond needs careful handle placement, simplified for MVP
      default: return 'rounded-lg';
    }
  };

  return (
    <div className={`min-w-[220px] max-w-[280px] bg-slate-900 border-2 transition-all duration-200 ${getBorderColor()} ${getShapeClasses()}`}>
      <Handle type="target" position={Position.Top} className="!bg-slate-500 !w-2 !h-2" />
      
      <div className={`p-3 ${data.shape === 'diamond' ? '-rotate-45' : ''}`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {isAi && <Brain size={16} className="text-purple-400" />}
            {isData && <FileText size={16} className="text-blue-400" />}
            {isRefactor && <RefreshCw size={16} className="text-emerald-400" />}
            <span className="font-semibold text-xs uppercase tracking-wider text-slate-400">
              {data.label || 'New Node'}
            </span>
          </div>
          <div className="flex items-center gap-1">
            {data.runState === RunState.RUNNING && <div className="animate-spin h-3 w-3 border-2 border-blue-400 border-t-transparent rounded-full" />}
            {data.runState === RunState.RAN && <CheckCircle2 size={14} className="text-green-500" />}
            {data.runState === RunState.ERROR && <AlertCircle size={14} className="text-red-500" />}
          </div>
        </div>

        <div className="text-sm text-slate-300 line-clamp-3 bg-slate-800/50 p-2 rounded border border-slate-700/50 min-h-[60px] font-mono">
          {data.prompt || data.input || 'Empty...'}
        </div>

        {data.isDirty && data.runState === RunState.RAN && (
          <div className="mt-2 text-[10px] text-yellow-500/80 italic">
            Outdated - re-run required
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Bottom} className="!bg-blue-500 !w-2 !h-2" />
    </div>
  );
};

export default memo(CustomNode);
