
# Context: Node Architecture & UI

*Note: Approximate location references are intentional.*

## Node Data Model (`types.ts`)
Nodes store metadata in their `data` object:
- `glowColor` & `glowIntensity`: Drives CSS `boxShadow` effects. Intensity uses 4 levels: 0 (Off), 1 (Min), 2 (Mid), 3 (Max).
- `icon`: String reference to Lucide-React icon names.
- `chatHistory`: Persists conversational context for refinements.
- `comment`: Stores internal user annotations for each node.

## Custom Node Rendering (`components/CustomNode.tsx`)
Nodes are highly dynamic:
- **Icons**: Resolved dynamically from the `LucideIcons` library (near top of component).
- **Auras**: The `getGlowStyles` function (roughly 25% into the file) calculates shadow spread based on intensity levels (0-3).
- **Comments Indicator**: A small `MessageSquareText` icon appears in the node header if a comment exists, providing immediate visual feedback on the canvas.
- **Shapes**: Supports rounded rects and diamonds (experimental).

## The Node Editor (`components/NodeEditor.tsx`)
The editor is the command center for node-specific logic and aesthetics:
- **Node Comments**: A dedicated "Internal Annotations" section (located immediately below the Step Label) allows users to save private notes about a node's specific purpose or quirks.
- **Visual Character Section**: (Middle of the file) Allows selecting from a curated list of logic-themed icons and vibrant glow colors. This section is **collapsible** and **collapsed by default** to optimize space.
- **Recall Feature**: A "Recall" button next to the input label allows users to insert data from **any ancestor node** in the graph directly into the current text cursor position.
- **Ancestor Reach**: Unlike execution context (which is direct parents only), the Recall feature traverses the entire chain of predecessors to provide access to any data that lead to the current step.
- **Raw Insertion**: Selecting a node from the Recall list inserts its raw output/input text directly into the textarea without any bracketed labels or headers.
- **Cursor Tracking**: The editor uses `useRef` to track the textarea's selection range, ensuring the "Recall" injection happens exactly where the user is typing.
- **4-Level Intensity Slider**: Explicit control from LVL 0 (OFF) to LVL 3 (MAX).
- **Prompt Logic**: Textareas for directing the LLM.

## Workflow Interactions (`App.tsx`)
- **Copy/Paste**: Handled via `handleCopy` and `handlePaste` (roughly 40% into the file), allowing users to duplicate complex node structures including their internal logic and comments.
- **Expandable Tips Footer**: (Near the end of the JSX) A "Muted" floating button that expands into a full-width footer on click. **Tips are shuffled every time the footer is opened** to provide variety. Features navigation arrows and a marquee effect for long tips combined with a fade-based transition between entries.
- **Canvas Anchoring**: The tips system and global status indicators (like 'Saved' and 'Copied') are anchored as `absolute` elements within the canvas container. This ensures that when the Node Editor sidebar opens, the canvas area shrinks and the tips push along with it, preventing overlap.
- **Creation Shortcuts**: Using Shift/Ctrl while dragging handles allows for rapid "type-aware" node creation without using the toolbox.
