
import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  Connection,
  Edge,
  Node,
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  Panel,
  MarkerType,
  useReactFlow,
  OnConnectStartParams,
} from 'reactflow';

import { 
  NodeType, 
  CanvasNodeData, 
  RunState, 
  CodeFile 
} from './types';
import CustomNode from './components/CustomNode';
import StickyNoteNode from './components/StickyNoteNode';
import NodeEditor from './components/NodeEditor';
import ButtonEdge from './components/ButtonEdge';
import { getLayoutedElements } from './utils/layout';
import { geminiService } from './services/geminiService';
import { 
  Plus, 
  Layout, 
  Download, 
  Upload, 
  GitBranch, 
  FileCode, 
  Search, 
  Trash2,
  Zap,
  CheckCircle,
  X as CloseIcon,
  Save,
  Link2Off,
  FilePlus,
  StickyNote as StickyIcon,
  Copy
} from 'lucide-react';

const nodeTypes = {
  aiPrompt: CustomNode,
  dataInput: CustomNode,
  refactor: CustomNode,
  stickyNote: StickyNoteNode,
};

const edgeTypes = {
  button: ButtonEdge,
};

const STORAGE_KEY = 'modular_ai_canvas_state';

const initialNodes: Node<CanvasNodeData>[] = [
  {
    id: 'node-1',
    type: NodeType.DATA_INPUT,
    data: { 
      label: 'Root Input', 
      type: NodeType.DATA_INPUT, 
      prompt: '', 
      input: 'Welcome to the Orchestration Canvas. Start by defining your core data or objective here.', 
      output: '', 
      runState: RunState.IDLE, 
      isDirty: false,
      shape: 'rectangle'
    },
    position: { x: 50, y: 50 },
  },
];

const AppContent: React.FC = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [copyFeedback, setCopyFeedback] = useState(false);
  
  const [activeBranches, setActiveBranches] = useState<Record<string, string>>({});
  
  // Drag-to-create tracking
  const connectingNodeId = useRef<string | null>(null);
  const isCancelledRef = useRef(false);
  const { screenToFlowPosition } = useReactFlow();

  const selectedNode = useMemo(() => 
    nodes.find(n => n.id === selectedNodeId) || null
  , [nodes, selectedNodeId]);

  // Keyboard Shortcut Handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        if (e.key === 'Escape' && connectingNodeId.current) {
          isCancelledRef.current = true;
        }
        return;
      }

      const isModKey = e.metaKey || e.ctrlKey;

      if (e.key === 'Escape') {
        if (connectingNodeId.current) {
          isCancelledRef.current = true;
        }
        setSelectedNodeId(null);
        setSelectedEdgeId(null);
        return;
      }

      if (isModKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setNodes((nds) => nds.map((node) => ({ ...node, selected: true })));
        setEdges((eds) => eds.map((edge) => ({ ...edge, selected: true })));
      }

      if (isModKey && e.key.toLowerCase() === 'c') {
        const projectData = JSON.stringify({ nodes, edges, activeBranches }, null, 2);
        navigator.clipboard.writeText(projectData).then(() => {
          setCopyFeedback(true);
          setTimeout(() => setCopyFeedback(false), 2000);
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nodes, edges, activeBranches, setNodes, setEdges]);

  useEffect(() => {
    const savedState = localStorage.getItem(STORAGE_KEY);
    if (savedState) {
      try {
        const { nodes: sNodes, edges: sEdges, activeBranches: sBranches } = JSON.parse(savedState);
        setNodes(sNodes);
        setEdges(sEdges);
        setActiveBranches(sBranches);
      } catch (e) {
        console.error("Failed to load saved state", e);
      }
    }
    
    const timer = setTimeout(() => {
      onLayout();
      setIsReady(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isReady) {
      const state = { nodes, edges, activeBranches };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      setLastSaved(new Date().toLocaleTimeString());
    }
  }, [nodes, edges, activeBranches, isReady]);

  const onConnectStart = useCallback((_: any, { nodeId }: OnConnectStartParams) => {
    connectingNodeId.current = nodeId;
    isCancelledRef.current = false;
  }, []);

  const onConnectEnd = useCallback(
    (event: MouseEvent | TouchEvent) => {
      if (isCancelledRef.current) {
        connectingNodeId.current = null;
        isCancelledRef.current = false;
        return;
      }

      const targetIsPane = (event.target as Element).classList.contains('react-flow__pane');

      if (targetIsPane && connectingNodeId.current) {
        const { clientX, clientY } = 'changedTouches' in event ? event.changedTouches[0] : event;
        const position = screenToFlowPosition({ x: clientX, y: clientY });
        
        const id = `node-${Date.now()}`;
        const newNode: Node<CanvasNodeData> = {
          id,
          type: NodeType.AI_PROMPT,
          data: {
            label: 'AI reasoning',
            type: NodeType.AI_PROMPT,
            prompt: '',
            input: '',
            output: '',
            runState: RunState.IDLE,
            isDirty: false,
            shape: 'rounded',
          },
          position,
        };

        const sourceId = connectingNodeId.current;
        const newEdge: Edge = {
          id: `edge-${sourceId}-${id}`,
          source: sourceId,
          target: id,
          type: 'button',
          animated: true,
          style: { stroke: '#3b82f6', strokeWidth: 2.5 },
          markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' },
        };

        setNodes((nds) => nds.concat(newNode));
        setEdges((eds) => addEdge(newEdge, eds));
        
        if (!activeBranches[sourceId]) {
          setActiveBranches(prev => ({ ...prev, [sourceId]: newEdge.id }));
        }

        setSelectedNodeId(id);
      }

      connectingNodeId.current = null;
    },
    [screenToFlowPosition, setNodes, setEdges, activeBranches]
  );

  const onConnect = useCallback((params: Connection) => {
    const source = nodes.find(n => n.id === params.source);
    const target = nodes.find(n => n.id === params.target);
    if (source?.type === NodeType.STICKY_NOTE || target?.type === NodeType.STICKY_NOTE) {
      return;
    }

    setEdges((eds) => addEdge({ 
      ...params, 
      type: 'button',
      animated: true, 
      style: { stroke: '#3b82f6', strokeWidth: 2.5 },
      markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' }
    }, eds));
  }, [setEdges, nodes]);

  const onLayout = useCallback(() => {
    setNodes((nds) => {
      const standardNodes = nds.filter(n => n.type !== NodeType.STICKY_NOTE);
      const stickyNodes = nds.filter(n => n.type === NodeType.STICKY_NOTE);
      const { nodes: layoutedStandardNodes } = getLayoutedElements(standardNodes, edges);
      return [...layoutedStandardNodes, ...stickyNodes];
    });
  }, [edges, setNodes]);

  const addNode = useCallback((type: NodeType, parentId?: string) => {
    const id = `node-${Date.now()}`;
    const newNode: Node<CanvasNodeData> = {
      id,
      type,
      data: {
        label: `${type === NodeType.AI_PROMPT ? 'AI reasoning' : type === NodeType.DATA_INPUT ? 'Data source' : type === NodeType.REFACTOR ? 'Refactor logic' : 'Documentation'}`,
        type,
        prompt: '',
        input: type === NodeType.STICKY_NOTE ? '# New Sticky Note\nAdd your context here...' : '',
        output: '',
        runState: RunState.IDLE,
        isDirty: false,
        shape: 'rounded',
        bgColor: type === NodeType.STICKY_NOTE ? 'rgba(30, 41, 59, 0.6)' : undefined,
      },
      zIndex: type === NodeType.STICKY_NOTE ? -10 : undefined,
      position: { x: 100, y: 100 },
      style: type === NodeType.STICKY_NOTE ? { width: 300, height: 200 } : undefined,
    };

    setNodes((nds) => nds.concat(newNode));
    
    if (type !== NodeType.STICKY_NOTE) {
      const sourceId = parentId || selectedNodeId;
      if (sourceId) {
        const sourceNode = nodes.find(n => n.id === sourceId);
        if (sourceNode?.type !== NodeType.STICKY_NOTE) {
          const newEdgeId = `edge-${sourceId}-${id}`;
          setEdges((eds) => {
            const existingOut = eds.filter(e => e.source === sourceId);
            const isAlternate = existingOut.length > 0;
            
            const newEdge: Edge = { 
              id: newEdgeId, 
              source: sourceId, 
              target: id, 
              type: 'button',
              animated: true,
              style: { 
                stroke: isAlternate ? '#f59e0b' : '#3b82f6', 
                strokeWidth: 2.5,
                opacity: isAlternate ? 0.6 : 1
              },
              markerEnd: { 
                type: MarkerType.ArrowClosed, 
                color: isAlternate ? '#f59e0b' : '#3b82f6' 
              },
              data: { isAlternate }
            };

            if (!activeBranches[sourceId]) {
              setActiveBranches(prev => ({ ...prev, [sourceId]: newEdgeId }));
            }

            return addEdge(newEdge, eds);
          });
          setTimeout(onLayout, 50);
        }
      }
    }
  }, [selectedNodeId, setEdges, setNodes, activeBranches, onLayout, nodes]);

  const updateNodeData = useCallback((id: string, newData: Partial<CanvasNodeData>) => {
    setNodes((nds) => nds.map((node) => {
      if (node.id === id) {
        return { ...node, data: { ...node.data, ...newData } };
      }
      return node;
    }));
  }, [setNodes]);

  const runNode = useCallback(async (id: string) => {
    const nodeToRun = nodes.find(n => n.id === id);
    if (!nodeToRun || nodeToRun.type === NodeType.STICKY_NOTE) return;

    updateNodeData(id, { runState: RunState.RUNNING });

    try {
      const incomingEdges = edges.filter(e => e.target === id);
      const parentOutputs = incomingEdges.map(edge => {
        const parent = nodes.find(n => n.id === edge.source);
        return `[Source: ${parent?.data.label}]\n${parent?.data.output || parent?.data.input || ''}`;
      }).join('\n\n---\n\n');

      let output = "";
      if (nodeToRun.data.type === NodeType.DATA_INPUT) {
        output = nodeToRun.data.input;
      } else {
        output = await geminiService.runPrompt(nodeToRun.data.prompt, parentOutputs);
      }

      updateNodeData(id, { 
        output, 
        runState: RunState.RAN, 
        isDirty: false 
      });

      const findDescendants = (nodeId: string): string[] => {
        const children = edges.filter(e => e.source === nodeId).map(e => e.target);
        return children.concat(children.flatMap(findDescendants));
      };
      const descendants = findDescendants(id);
      setNodes(nds => nds.map(n => descendants.includes(n.id) ? { ...n, data: { ...n.data, isDirty: true } } : n));

    } catch (error) {
      console.error(error);
      updateNodeData(id, { runState: RunState.ERROR });
    }
  }, [nodes, edges, updateNodeData, setNodes]);

  const deleteNode = useCallback((id: string) => {
    setNodes((nds) => nds.filter((n) => n.id !== id));
    setEdges((eds) => eds.filter((e) => e.source !== id && e.target !== id));
    setSelectedNodeId(null);
  }, [setNodes, setEdges]);

  const deleteEdge = useCallback((id: string) => {
    setEdges((eds) => eds.filter((e) => e.id !== id));
    setSelectedEdgeId(null);
  }, [setEdges]);

  const resetCanvas = useCallback(() => {
    if (confirm("Reset everything and start a new project?")) {
      setNodes(initialNodes);
      setEdges([]);
      setActiveBranches({});
      localStorage.removeItem(STORAGE_KEY);
      setTimeout(onLayout, 100);
    }
  }, [setNodes, setEdges, onLayout]);

  const toggleActiveBranch = (sourceId: string, edgeId: string) => {
    setActiveBranches(prev => ({ ...prev, [sourceId]: edgeId }));
    setEdges(eds => eds.map(e => {
      if (e.source === sourceId) {
        const isActive = e.id === edgeId;
        return {
          ...e,
          style: (e.style && typeof e.style === 'object') ? { 
            ...e.style, 
            stroke: isActive ? '#3b82f6' : '#475569',
            opacity: isActive ? 1 : 0.4,
            strokeDasharray: isActive ? '0' : '5,5'
          } : {
            stroke: isActive ? '#3b82f6' : '#475569',
            opacity: isActive ? 1 : 0.4,
            strokeDasharray: isActive ? '0' : '5,5'
          },
          animated: isActive,
          markerEnd: (e.markerEnd && typeof e.markerEnd === 'object') ? { 
            ...e.markerEnd, 
            color: isActive ? '#3b82f6' : '#475569' 
          } : e.markerEnd
        };
      }
      return e;
    }));
  };

  const exportWorkflow = () => {
    const data = JSON.stringify({ nodes, edges, activeBranches }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `workflow-${Date.now()}.json`;
    link.click();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setNodes(parsed.nodes || []);
        setEdges(parsed.edges || []);
        setActiveBranches(parsed.activeBranches || {});
      } catch (err) {
        alert("Invalid workflow JSON");
      }
    };
    reader.readAsText(file);
  };

  const summarizeWorkflow = async () => {
    setIsSummarizing(true);
    try {
      const summaryText = await geminiService.summarizeWorkflow(JSON.stringify({ nodes, edges }));
      setSummary(summaryText);
    } catch (error) {
      alert("Failed to summarize workflow");
    } finally {
      setIsSummarizing(false);
    }
  };

  const outgoingEdges = useMemo(() => 
    edges.filter(e => e.source === selectedNodeId)
  , [edges, selectedNodeId]);

  const upstreamContext = useMemo(() => {
    if (!selectedNodeId) return undefined;
    const incomingEdges = edges.filter(e => e.target === selectedNodeId);
    return incomingEdges.map(edge => {
      const parent = nodes.find(n => n.id === edge.source);
      return `[Source: ${parent?.data.label}]\n${parent?.data.output || parent?.data.input || ''}`;
    }).join('\n\n---\n\n');
  }, [edges, nodes, selectedNodeId]);

  if (!isReady) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-950">
        <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  // Determine if the action panel should be visible (only if there are actual buttons to show)
  const showActionPanel = selectedEdgeId || (selectedNodeId && outgoingEdges.length > 1);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-100 selection:bg-blue-500/30 overflow-hidden">
      {/* Shortcut Feedback Toast */}
      {copyFeedback && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[100] bg-emerald-600 text-white px-6 py-3 rounded-full font-bold shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300">
          <Copy size={18} />
          Workflow JSON copied to clipboard
        </div>
      )}

      {/* Sidebar Toolrail */}
      <aside className="w-16 border-r border-slate-800 flex flex-col items-center py-6 space-y-6 bg-slate-900/60 backdrop-blur-2xl z-20">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 mb-6">
          <Zap className="text-white fill-white" size={18} />
        </div>
        
        <div className="flex-1 flex flex-col items-center space-y-5">
          <button onClick={() => addNode(NodeType.AI_PROMPT)} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <Plus size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Add AI Step</span>
          </button>
          
          <button onClick={() => addNode(NodeType.DATA_INPUT)} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <FileCode size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Add Data Step</span>
          </button>

          <button onClick={() => addNode(NodeType.REFACTOR)} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <GitBranch size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Add Refactor</span>
          </button>

          <button onClick={() => addNode(NodeType.STICKY_NOTE)} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <StickyIcon size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Add Sticky Note</span>
          </button>

          <div className="h-px w-8 bg-slate-800 my-2" />

          <button onClick={onLayout} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <Layout size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Auto Layout</span>
          </button>

          <button onClick={summarizeWorkflow} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <Search size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Logical Analysis</span>
          </button>

          <button onClick={resetCanvas} className="p-2.5 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-950/30 transition-all group relative border border-transparent hover:border-red-900/40">
            <FilePlus size={20} />
            <span className="absolute left-14 bg-red-900/80 border border-red-800 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">New Project</span>
          </button>
        </div>

        <div className="flex flex-col items-center space-y-5 pb-6">
          <button onClick={() => setLastSaved(new Date().toLocaleTimeString())} className="p-2.5 rounded-xl text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/30 transition-all group relative border border-transparent hover:border-emerald-900/40">
            <Save size={20} />
            <span className="absolute left-14 bg-emerald-900/80 border border-emerald-800 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Force Save</span>
          </button>
          <label className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer group relative border border-transparent hover:border-slate-700">
            <Upload size={20} />
            <input type="file" className="hidden" accept=".json" onChange={handleFileUpload} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Import JSON</span>
          </label>
          <button onClick={exportWorkflow} className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all group relative border border-transparent hover:border-slate-700">
            <Download size={20} />
            <span className="absolute left-14 bg-slate-800 border border-slate-700 text-[10px] uppercase font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">Export JSON</span>
          </button>
        </div>
      </aside>

      {/* Canvas Area */}
      <main className="flex-1 relative overflow-hidden h-full w-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onConnectStart={onConnectStart}
          onConnectEnd={onConnectEnd}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          onNodeClick={(_, node) => {
            setSelectedNodeId(node.id);
            setSelectedEdgeId(null);
          }}
          onEdgeClick={(_, edge) => {
            setSelectedEdgeId(edge.id);
            setSelectedNodeId(null);
          }}
          onPaneClick={() => {
            setSelectedNodeId(null);
            setSelectedEdgeId(null);
          }}
          fitView
          snapToGrid
          snapGrid={[15, 15]}
          style={{ width: '100%', height: '100%' }}
        >
          <Background color="#334155" gap={20} size={1} />
          <Controls className="!bg-slate-900 !border-slate-700 !fill-slate-300 shadow-2xl" />
          
          <Panel position="top-left" className="m-6">
            <div className="bg-slate-900/80 backdrop-blur-xl px-5 py-4 rounded-2xl border border-slate-800 shadow-2xl ring-1 ring-white/5">
              <h1 className="text-sm font-bold flex items-center gap-3">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span>
                </span>
                Modular Orchestration
              </h1>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Persistence</span>
                  <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle size={10} /> Auto-saved {lastSaved}
                  </span>
                </div>
              </div>
            </div>
          </Panel>

          {/* Selection Actions Panel */}
          {showActionPanel && (
             <Panel position="bottom-center" className="mb-6 animate-in slide-in-from-bottom-4 duration-300">
               <div className="bg-slate-900/90 backdrop-blur-2xl px-5 py-3 rounded-2xl border border-slate-700 shadow-2xl flex items-center gap-6">
                 {selectedEdgeId && (
                   <button 
                    onClick={() => deleteEdge(selectedEdgeId)}
                    className="flex items-center gap-2 text-xs font-bold text-red-400 hover:text-red-300 transition-colors"
                   >
                     <Link2Off size={16} /> Break Connection
                   </button>
                 )}
                 
                 {selectedNodeId && outgoingEdges.length > 1 && (
                   <div className="flex items-center gap-3 border-l border-slate-800 pl-6">
                     <span className="text-[10px] uppercase font-bold text-blue-400 tracking-widest">Active Branch:</span>
                     <div className="flex gap-2">
                       {outgoingEdges.map((edge, idx) => {
                         const isActive = activeBranches[selectedNodeId!] === edge.id;
                         return (
                           <button
                             key={edge.id}
                             onClick={() => toggleActiveBranch(selectedNodeId!, edge.id)}
                             className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all ${
                               isActive 
                                 ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                                 : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                             }`}
                           >
                             Path {idx + 1}
                           </button>
                         );
                       })}
                     </div>
                   </div>
                 )}
               </div>
             </Panel>
          )}
        </ReactFlow>

        {/* Analysis Modal */}
        {summary && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-8 bg-black/70 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-[0_0_100px_rgba(0,0,0,0.5)] w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden ring-1 ring-white/10">
              <div className="px-8 py-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Search size={24} className="text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Execution Analysis</h3>
                    <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Gemini 3 Pro Logic Synthesis</p>
                  </div>
                </div>
                <button onClick={() => setSummary(null)} className="p-2 rounded-full hover:bg-slate-800 text-slate-400 transition-colors">
                  <CloseIcon size={24} />
                </button>
              </div>
              <div className="p-8 overflow-y-auto text-sm text-slate-300 leading-relaxed font-mono custom-scrollbar">
                <div className="prose prose-invert max-w-none">
                  {summary.split('\n').map((line, i) => (
                    <p key={i} className="mb-4">{line}</p>
                  ))}
                </div>
              </div>
              <div className="px-8 py-6 border-t border-slate-800 bg-slate-900/50 flex justify-between items-center">
                <p className="text-xs text-slate-500 font-medium italic">Logic path enumeration complete.</p>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(summary!);
                    alert("Analysis copied to clipboard");
                  }}
                  className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-blue-600/20 transition-all active:scale-95"
                >
                  Copy Report
                </button>
              </div>
            </div>
          </div>
        )}

        {isSummarizing && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/40 backdrop-blur-md animate-in fade-in duration-500">
            <div className="relative">
              <div className="animate-spin h-16 w-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-4 w-4 bg-blue-500 rounded-full animate-pulse" />
              </div>
            </div>
            <p className="text-xl font-bold text-white mt-8 tracking-tight">Synthesizing Workflow...</p>
            <p className="text-sm text-slate-500 mt-2 font-mono">Mapping logical clusters to production n8n nodes</p>
          </div>
        )}
      </main>

      {/* Node Editor Sidebar */}
      <NodeEditor
        node={selectedNode}
        onUpdate={updateNodeData}
        onRun={runNode}
        onDelete={deleteNode}
        onClose={() => setSelectedNodeId(null)}
        upstreamContext={upstreamContext}
      />
    </div>
  );
};

export default function App() {
  return (
    <ReactFlowProvider>
      <AppContent />
    </ReactFlowProvider>
  );
}
