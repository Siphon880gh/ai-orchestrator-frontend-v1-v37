
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

export class GeminiService {
  /**
   * Run a logic prompt against the Gemini model with optional context from previous nodes.
   */
  async runPrompt(prompt: string, context?: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const fullPrompt = context 
        ? `Context Information:\n${context}\n\nTask:\n${prompt}`
        : prompt;

      const response = await ai.models.generateContent({
        // Using correct model for complex text tasks as per guidelines
        model: 'gemini-3-pro-preview',
        contents: fullPrompt,
      });

      // Using .text property instead of .text() method
      return response.text || "No response generated.";
    } catch (error) {
      console.error("Gemini Error:", error);
      throw error;
    }
  }

  /**
   * Interactive Chat session for refined logic.
   */
  async sendChatMessage(message: string, history: ChatMessage[], context?: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const chat = ai.chats.create({
        model: 'gemini-3-pro-preview',
        config: {
          systemInstruction: context ? `CONTEXT:\n${context}\n\nYou are a specialized AI logic component in a larger workflow. Assist the user in refining the output for this specific step.` : "You are a specialized AI logic component.",
        },
        // We pass the history as is.
        history: history as any,
      });

      const response = await chat.sendMessage({ message });
      const responseText = response.text || "No response.";

      // Fix: Property 'history' is private and only accessible within class 'Chat'.
      // We manually construct the updated history to return for state management.
      const updatedHistory: ChatMessage[] = [
        ...history,
        { role: 'user', parts: [{ text: message }] },
        { role: 'model', parts: [{ text: responseText }] }
      ];
      
      return {
        text: responseText,
        history: updatedHistory
      };
    } catch (error) {
      console.error("Gemini Chat Error:", error);
      throw error;
    }
  }

  /**
   * Summarize the entire workflow logic and suggest automation improvements.
   */
  async summarizeWorkflow(workflowJson: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        // Using correct model for basic text tasks as per guidelines
        model: 'gemini-3-flash-preview',
        contents: `Analyze this workflow JSON and provide a high-level summary of the logic paths and n8n automation suggestions:\n\n${workflowJson}`,
      });
      // Using .text property instead of .text() method
      return response.text || "Failed to summarize.";
    } catch (error) {
      console.error("Gemini Summarization Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
