
# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Multi-User Authentication**, **Workflow Management** (Naming, Forking, Library), **Interactive Chat Agents** for multi-turn refinement, **Visual Character Customization**, a robust **Ancestor Recall** system for raw data reuse, a **Global Variables** system for cross-node state persistence, **JS Execution** with global variable modification, **API Request** support with interpolation, and a modern, expandable **Tips Footer**.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Content**: Marked (Markdown rendering)

## File Tree & Roles
- `App.tsx`: The core hub. Manages auth, graph state, workflow lifecycle, and the **Global Variables** state. Implements interpolation logic for `{}` curly brace expressions, including the **$() node lookup** utility.
- `types.ts`: Defines data models, including `WorkflowState` which now persists `globalVariables`.
- `services/geminiService.ts`: Handles generation and stateful chat logic.
- `components/CustomNode.tsx`: Visual representation of logic nodes with custom icons and status indicators.
- `components/NodeEditor.tsx`: Configuration UI with **Interpolation Previews** for visual feedback on curly brace logic and cross-node referencing.
- `components/StickyNoteNode.tsx`: Scalable documentation nodes with Markdown support.

## High-Level Code Flow
1. **Authentication**: Users login/signup to access their isolated workspace.
2. **Graph Construction**: Users add nodes via drag-and-create shortcuts or the toolbox.
3. **Execution**: Logic steps are executed. 
   - **Code Nodes** can read/write to `global` variables.
   - **Interpolation** resolves `{global.var}`, `{expression}`, and `{ $("Node Name").output }` in URLs, prompts, and inputs before processing.
4. **Variable Management**: A dedicated Variable Explorer allows viewing all persisted global states.
5. **Persistence**: Autosave triggers user-prefixed localStorage updates, including node positions, edges, and global variables.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.
