# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Interactive Chat Agents** for multi-turn refinement, **Visual Character Customization** (icons and glow states), and a modern, expandable **Tips Footer** for user onboarding.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Content**: Marked (Markdown rendering)

## File Tree & Roles
- `App.tsx` (approx. 850 lines): The core orchestration hub. Manages graph state, undo/redo, **Copy/Paste shortcuts**, and the expandable **Modern Tips Footer**.
- `types.ts` (approx. 70 lines): Defines `CanvasNodeData`, including appearance fields like `icon`, `glowColor`, and `glowIntensity`.
- `services/geminiService.ts` (approx. 80 lines): Handles generation and stateful chat logic.
- `components/CustomNode.tsx` (approx. 100 lines): Visual representation of logic nodes, rendering custom icons and CSS-based "Aura Glow" effects with 4 intensity levels.
- `components/NodeEditor.tsx` (approx. 550 lines): Configuration UI. Now features an "Appearance" section for node icons and glow settings alongside Chat Agent controls.
- `components/StickyNoteNode.tsx` (approx. 50 lines): Scalable documentation nodes with Markdown support.

## High-Level Code Flow
1. **Graph Construction**: Users add nodes via the toolbox or drag-and-create shortcuts. Nodes can be duplicated via Cmd+C/Cmd+V.
2. **Visual Styling**: Nodes are customized with icons and glow effects to distinguish logical groups.
3. **Execution/Refinement**: 
   - **One-shot**: Execute a prompt using upstream context.
   - **Iterative (Chat)**: Refine steps through multi-turn conversational agents.
4. **Finalization**: Saved outputs propagate down the graph for subsequent processing.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.