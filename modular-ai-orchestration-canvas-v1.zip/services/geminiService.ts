
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  /**
   * Run a logic prompt against the Gemini model with optional context from previous nodes.
   */
  async runPrompt(prompt: string, context?: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const fullPrompt = context 
        ? `Context Information:\n${context}\n\nTask:\n${prompt}`
        : prompt;

      // Using gemini-3-pro-preview for logic processing as it is a complex reasoning task
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: fullPrompt,
      });

      return response.text || "No response generated.";
    } catch (error) {
      console.error("Gemini Error:", error);
      throw error;
    }
  }

  /**
   * Summarize the entire workflow logic and suggest automation improvements.
   */
  async summarizeWorkflow(workflowJson: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // Using gemini-3-pro-preview for workflow analysis and summarization
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Analyze this workflow JSON and provide a high-level summary of the logic paths and n8n automation suggestions:\n\n${workflowJson}`,
      });
      return response.text || "Failed to summarize.";
    } catch (error) {
      console.error("Gemini Summarization Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
