
export enum NodeType {
  AI_PROMPT = 'aiPrompt',
  DATA_INPUT = 'dataInput',
  REFACTOR = 'refactor',
  STICKY_NOTE = 'stickyNote'
}

export enum RunState {
  IDLE = 'idle',
  RUNNING = 'running',
  RAN = 'ran',
  ERROR = 'error'
}

export interface CanvasNodeData {
  label: string;
  type: NodeType;
  prompt: string;
  input: string;
  output: string;
  runState: RunState;
  isDirty: boolean;
  shape: 'rectangle' | 'rounded' | 'diamond';
  bgColor?: string;
}

export interface WorkflowMetadata {
  id: string;
  name: string;
  lastModified: string;
}

export interface WorkflowState {
  nodes: any[];
  edges: any[];
  activeBranches: Record<string, string>;
}

export interface CodeFile {
  name: string;
  content: string;
  path: string;
}
