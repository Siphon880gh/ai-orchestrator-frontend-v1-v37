# Project Context: Modular AI Orchestration Canvas

*Note: Line numbers are referenced approximately to maintain accuracy during small refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a React-based visual tool for designing AI workflows. It treats a directed acyclic graph (DAG) as a series of logical instructions. Data flows from parent nodes to child nodes, aggregating context along the way.

## Tech Stack
- **Framework**: React 19 (via ESM imports)
- **Styling**: Tailwind CSS
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre (for automatic graph positioning)
- **Content**: Marked (for Markdown rendering in sticky notes)

## File Structure (Approximate Line Counts)
- `App.tsx` (~650 lines): Main application shell, state management, and workflow orchestration.
- `types.ts` (~50 lines): Core enums and interfaces for nodes and workflows.
- `services/geminiService.ts` (~50 lines): Wrapper for Gemini API calls.
- `components/CustomNode.tsx` (~70 lines): Standard node UI (Data, AI, Refactor).
- `components/NodeEditor.tsx` (~250 lines): Sidebar for node configuration.
- `components/StickyNoteNode.tsx` (~50 lines): Specialized Markdown documentation node.
- `utils/layout.ts` (~40 lines): Dagre-based layouting logic.

## Core Architecture
The app uses a "Single Source of Truth" pattern in `App.tsx`. All node data, edges, and workflow metadata are stored in the top-level state.

### Data Flow
1. **Inputs**: Static data defined in `DATA_INPUT` nodes.
2. **Context Aggregation**: When a node runs, it collects the `output` from all parents.
3. **Execution**: The `geminiService` sends the combined context + the node's specific `prompt` to Gemini.
4. **Persistence**: The resulting `output` is saved back into the node's state and becomes available to children.

For detailed runtime logic, see `context-runtime.md`. For node-specific details, see `context-nodes.md`.