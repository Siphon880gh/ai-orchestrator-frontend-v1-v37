# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Multi-User Authentication**, **Interactive Chat Agents** for multi-turn refinement, **Visual Character Customization**, a robust **Ancestor Recall** system for raw data reuse across the entire logic chain, **Internal Annotations (Comments)** grouped with node labels for documentation, and a modern, expandable **Tips Footer**.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Content**: Marked (Markdown rendering)

## File Tree & Roles
- `App.tsx`: The core hub. Manages auth, graph state, undo/redo, and the tips system. Uses `Brain`, `Database`, and `Rotate3d` icons for workflow orchestration.
- `types.ts`: Defines data models, including `User` and `CanvasNodeData`.
- `services/geminiService.ts`: Handles generation and stateful chat logic.
- `components/CustomNode.tsx`: Visual representation of logic nodes with custom icons, CSS "Auras", and metadata indicators (like comments).
- `components/NodeEditor.tsx`: Configuration UI for logic, aesthetics, and annotations.
- `components/StickyNoteNode.tsx`: Scalable documentation nodes with Markdown support.

## High-Level Code Flow
1. **Authentication**: Users login/signup to access their isolated workspace. Alice is pre-seeded for testing.
2. **Graph Construction**: Users add nodes via drag-and-create shortcuts.
3. **Visual Styling**: Nodes are customized with icons, glow effects, and internal comments.
4. **Execution**: Logic steps are executed with upstream context aggregation (direct parents).
5. **Data Reuse**: The "Recall" feature in the editor traverses the entire predecessor graph to allow injecting raw ancestor data into child prompts at the cursor position.
6. **Persistence**: Autosave triggers user-prefixed localStorage updates.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.
