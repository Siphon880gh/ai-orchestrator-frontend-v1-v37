import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  Connection,
  Edge,
  Node,
  Panel,
  ReactFlowProvider,
  useReactFlow,
  useNodesState,
  useEdgesState,
  MarkerType,
  OnNodesChange,
  OnEdgesChange,
  OnConnectStartParams,
} from 'reactflow';

// Components
import CustomNode from './components/CustomNode.tsx';
import StickyNoteNode from './components/StickyNoteNode.tsx';
import ButtonEdge from './components/ButtonEdge.tsx';
import NodeEditor from './components/NodeEditor.tsx';

// Config & Types
import { NODE_CREATION_MAPPINGS } from './config/nodeMappings.ts';
import { geminiService } from './services/geminiService.ts';
import { getLayoutedElements } from './utils/layout.ts';
import { NodeType, RunState, CanvasNodeData, WorkflowMetadata, WorkflowState, User } from './types.ts';

// Icons
import { 
  Undo2, 
  Redo2, 
  GitFork,
  FolderOpen, 
  Trash2, 
  X as CloseIcon, 
  PlusSquare,
  Plus,
  History,
  ChevronRight,
  ChevronLeft,
  StickyNote as StickyIcon,
  Loader2,
  ClipboardCheck,
  Download,
  Upload,
  Info,
  Lightbulb,
  Maximize2,
  Minimize2,
  User as UserIcon,
  LogOut,
  LogIn,
  Key,
  Check,
  Brain,
  Database,
  Rotate3d
} from 'lucide-react';

const nodeTypes = {
  aiPrompt: CustomNode,
  dataInput: CustomNode,
  refactor: CustomNode,
  stickyNote: StickyNoteNode,
};

const edgeTypes = {
  buttonEdge: ButtonEdge,
};

const USERS_KEY = 'modular_ai_canvas_users';
const CURRENT_SESSION_KEY = 'modular_ai_canvas_session';

const TIPS = [
  "Copy and paste a node to duplicate it - use keyboard shortcuts (Cmd/Ctrl+C, Cmd/Ctrl+V).",
  "You can add legends in a sticky note mentioning glow color and or icon for a node. You can design a node to have glow color and or icon in the sidebar.",
  "Drag from any handle onto the canvas to create a new node of a specific type (Shift for Data, Ctrl for Transformation).",
  "Use the Interactive Chat Agent to refine a node's output through multi-turn conversation.",
  "Double-click the canvas to fit the view to all nodes automatically.",
  "Assign glow intensity (4 levels) to categorize logical sections of your workflow visually."
];

const shuffleArray = <T,>(array: T[]): T[] => {
  const newArr = [...array];
  for (let i = newArr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
  }
  return newArr;
};

const getInitialNodes = (): Node<CanvasNodeData>[] => [
  {
    id: 'root-1',
    type: NodeType.DATA_INPUT,
    position: { x: 100, y: 100 },
    zIndex: 1,
    data: {
      label: 'Initial Context',
      type: NodeType.DATA_INPUT,
      prompt: '',
      input: 'The project is a logic graph builder for AI-powered workflows.',
      output: 'The project is a logic graph builder for AI-powered workflows.',
      runState: RunState.RAN,
      isDirty: false,
      shape: 'rounded',
    },
  },
];

const AppContent = () => {
  const { fitView, screenToFlowPosition } = useReactFlow();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const loadedUserRef = useRef<string | null>(null);
  
  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  const [nodes, setNodes, onNodesChangeDefault] = useNodesState(getInitialNodes());
  const [edges, setEdges, onEdgesChangeDefault] = useEdgesState([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [activeBranches, setActiveBranches] = useState<Record<string, string>>({});
  
  // Workflow Management
  const [workflows, setWorkflows] = useState<WorkflowMetadata[]>([]);
  const [currentWorkflowId, setCurrentWorkflowId] = useState<string>('');
  const [currentWorkflowName, setCurrentWorkflowName] = useState<string>('Untitled Workflow');
  const [isManagerOpen, setIsManagerOpen] = useState(false);
  const [isSaveAsOpen, setIsSaveAsOpen] = useState(false);
  const [saveAsName, setSaveAsName] = useState('');
  
  // App States
  const [isSaving, setIsSaving] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);
  
  // Modern Tips State
  const [isTipsExpanded, setIsTipsExpanded] = useState(false);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [tipFade, setTipFade] = useState(false);
  const [shuffledTips, setShuffledTips] = useState<string[]>([...TIPS]);
  const tipTextRef = useRef<HTMLParagraphElement>(null);
  const [isMarqueeActive, setIsMarqueeActive] = useState(false);

  // Connection Tracking
  const connectingNodeId = useRef<string | null>(null);
  const isCancelledRef = useRef(false);

  // Clipboard Internal Reference
  const clipboard = useRef<{ nodes: Node<CanvasNodeData>[], edges: Edge[] } | null>(null);

  // Undo/Redo History
  const [history, setHistory] = useState<WorkflowState[]>([]);
  const [future, setFuture] = useState<WorkflowState[]>([]);
  const isInternalChange = useRef(false);

  // Memoized Storage Keys
  const storagePrefix = useMemo(() => 
    currentUser ? `user_${currentUser.email.replace(/[@.]/g, '_')}_` : 'guest_',
    [currentUser]
  );
  
  const INDEX_KEY = useMemo(() => `${storagePrefix}modular_ai_canvas_index`, [storagePrefix]);
  const LAST_USED_KEY = useMemo(() => `${storagePrefix}modular_ai_canvas_last_used`, [storagePrefix]);

  // --- Auth Logic ---

  const seedAlice = useCallback(() => {
    const usersStr = localStorage.getItem(USERS_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];
    const aliceExists = users.some(u => u.email === 'alice@example.com');
    if (!aliceExists) {
      users.push({ email: 'alice@example.com', password: 'password' });
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  }, []);

  useEffect(() => {
    seedAlice();
    
    // Check both localStorage (persistent) and sessionStorage (temporary)
    const storedSession = localStorage.getItem(CURRENT_SESSION_KEY);
    const sessionOnly = sessionStorage.getItem(CURRENT_SESSION_KEY);
    
    let activeUser: (User & { expiresAt?: number }) | null = null;

    if (storedSession) {
      try {
        const parsed = JSON.parse(storedSession);
        // Validate expiration for persistent sessions
        if (parsed.expiresAt && Date.now() > parsed.expiresAt) {
          localStorage.removeItem(CURRENT_SESSION_KEY);
        } else {
          activeUser = parsed;
        }
      } catch (e) {
        localStorage.removeItem(CURRENT_SESSION_KEY);
      }
    }

    if (!activeUser && sessionOnly) {
      try {
        activeUser = JSON.parse(sessionOnly);
      } catch (e) {
        sessionStorage.removeItem(CURRENT_SESSION_KEY);
      }
    }

    if (activeUser) {
      setCurrentUser(activeUser);
    }

    setIsReady(true);
  }, [seedAlice]);

  const handleAuth = () => {
    setAuthError('');
    if (!authEmail || !authPassword) {
      setAuthError('Email and password are required');
      return;
    }

    const usersStr = localStorage.getItem(USERS_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];

    if (authMode === 'signup') {
      if (users.some(u => u.email === authEmail)) {
        setAuthError('User already exists');
        return;
      }
      const newUser = { email: authEmail, password: authPassword };
      users.push(newUser);
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      login(newUser);
    } else {
      const user = users.find(u => u.email === authEmail && u.password === authPassword);
      if (user) {
        login(user);
      } else {
        setAuthError('Invalid credentials');
      }
    }
  };

  const login = (user: User) => {
    if (rememberMe) {
      // 30 days = 30 * 24 * 60 * 60 * 1000ms
      const sessionData = { 
        ...user, 
        expiresAt: Date.now() + (30 * 24 * 60 * 60 * 1000) 
      };
      localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(sessionData));
      sessionStorage.removeItem(CURRENT_SESSION_KEY); // Clean up if previous temp session exists
    } else {
      sessionStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(user));
      localStorage.removeItem(CURRENT_SESSION_KEY); // Clean up persistent session
    }
    
    setCurrentUser(user);
    setIsAuthModalOpen(false);
    setAuthEmail('');
    setAuthPassword('');
    loadedUserRef.current = null; // Allow reload for the new user
  };

  const logout = () => {
    localStorage.removeItem(CURRENT_SESSION_KEY);
    sessionStorage.removeItem(CURRENT_SESSION_KEY);
    setCurrentUser(null);
    setNodes(getInitialNodes());
    setEdges([]);
    setWorkflows([]);
    setCurrentWorkflowId('');
    setCurrentWorkflowName('Untitled Workflow');
    loadedUserRef.current = null;
  };

  // --- History Management ---

  const recordHistory = useCallback(() => {
    if (isInternalChange.current) return;
    const currentState: WorkflowState = { 
      nodes: JSON.parse(JSON.stringify(nodes)), 
      edges: JSON.parse(JSON.stringify(edges)), 
      activeBranches: { ...activeBranches } 
    };
    setHistory(prev => [...prev.slice(-49), currentState]);
    setFuture([]);
  }, [nodes, edges, activeBranches]);

  const undo = useCallback(() => {
    if (history.length === 0) return;
    isInternalChange.current = true;
    const prev = history[history.length - 1];
    const newHistory = history.slice(0, history.length - 1);
    
    const current: WorkflowState = { 
      nodes: JSON.parse(JSON.stringify(nodes)), 
      edges: JSON.parse(JSON.stringify(edges)), 
      activeBranches: { ...activeBranches } 
    };
    setFuture(f => [current, ...f]);
    
    setNodes(prev.nodes);
    setEdges(prev.edges);
    setActiveBranches(prev.activeBranches || {});
    setHistory(newHistory);
    
    setTimeout(() => { isInternalChange.current = false; }, 50);
  }, [history, nodes, edges, activeBranches, setNodes, setEdges]);

  const redo = useCallback(() => {
    if (future.length === 0) return;
    isInternalChange.current = true;
    const next = future[0];
    const newFuture = future.slice(1);
    
    const current: WorkflowState = { 
      nodes: JSON.parse(JSON.stringify(nodes)), 
      edges: JSON.parse(JSON.stringify(edges)), 
      activeBranches: { ...activeBranches } 
    };
    setHistory(h => [...h, current]);
    
    setNodes(next.nodes);
    setEdges(next.edges);
    setActiveBranches(next.activeBranches || {});
    setFuture(newFuture);
    
    setTimeout(() => { isInternalChange.current = false; }, 50);
  }, [future, nodes, edges, activeBranches, setNodes, setEdges]);

  // --- Persistence Logic ---

  const persistWorkflowsIndex = useCallback((index: WorkflowMetadata[]) => {
    localStorage.setItem(INDEX_KEY, JSON.stringify(index));
    setWorkflows(index);
  }, [INDEX_KEY]);

  const createNewWorkflow = useCallback((name: string = 'Untitled Workflow', baseIndex?: WorkflowMetadata[]) => {
    const id = `wf-${Date.now()}`;
    const newMetadata: WorkflowMetadata = {
      id,
      name,
      lastModified: new Date().toISOString()
    };
    
    const updatedIndex = [newMetadata, ...(baseIndex || workflows)];
    persistWorkflowsIndex(updatedIndex);
    
    const baseNodes = getInitialNodes();
    const initialState: WorkflowState = { nodes: baseNodes, edges: [], activeBranches: {} };
    localStorage.setItem(`${storagePrefix}workflow_${id}`, JSON.stringify(initialState));
    
    setCurrentWorkflowId(id);
    setCurrentWorkflowName(name);
    setNodes(baseNodes);
    setEdges([]);
    setActiveBranches({});
    setHistory([]);
    setFuture([]);
    localStorage.setItem(LAST_USED_KEY, id);
    setIsManagerOpen(false);
  }, [workflows, persistWorkflowsIndex, setNodes, setEdges, storagePrefix, LAST_USED_KEY]);

  const loadWorkflow = useCallback((id: string, customIndex?: WorkflowMetadata[]) => {
    const dataStr = localStorage.getItem(`${storagePrefix}workflow_${id}`);
    const indexToSearch = customIndex || workflows;
    const metadata = indexToSearch.find(w => w.id === id);
    if (dataStr && metadata) {
      try {
        const state: WorkflowState = JSON.parse(dataStr);
        setNodes(state.nodes);
        setEdges(state.edges);
        setActiveBranches(state.activeBranches || {});
        setCurrentWorkflowId(id);
        setCurrentWorkflowName(metadata.name);
        setHistory([]);
        setFuture([]);
        localStorage.setItem(LAST_USED_KEY, id);
        setIsManagerOpen(false);
        setTimeout(() => fitView({ padding: 0.2 }), 100);
      } catch (err) {
        console.error("Failed to parse workflow data", err);
      }
    }
  }, [workflows, setNodes, setEdges, fitView, storagePrefix, LAST_USED_KEY]);

  const deleteWorkflow = useCallback((id: string) => {
    const indexStr = localStorage.getItem(INDEX_KEY);
    const index: WorkflowMetadata[] = indexStr ? JSON.parse(indexStr) : [];
    const wf = index.find(w => w.id === id);
    if (!wf) return;
    if (window.confirm(`Are you sure you want to delete "${wf.name}"?`)) {
      const updatedIndex = index.filter(w => w.id !== id);
      localStorage.setItem(INDEX_KEY, JSON.stringify(updatedIndex));
      localStorage.removeItem(`${storagePrefix}workflow_${id}`);
      setWorkflows(updatedIndex);
      if (currentWorkflowId === id) {
        if (updatedIndex.length > 0) loadWorkflow(updatedIndex[0].id, updatedIndex);
        else createNewWorkflow('New Workflow', []);
      }
    }
  }, [currentWorkflowId, loadWorkflow, createNewWorkflow, INDEX_KEY, storagePrefix]);

  // --- Initial Session Load ---
  useEffect(() => {
    const userEmail = currentUser?.email || 'guest';
    if (isReady && loadedUserRef.current !== userEmail) {
      loadedUserRef.current = userEmail;
      
      const indexStr = localStorage.getItem(INDEX_KEY);
      const index: WorkflowMetadata[] = indexStr ? JSON.parse(indexStr) : [];
      setWorkflows(index);
      
      const lastId = localStorage.getItem(LAST_USED_KEY);
      const lastWorkflow = index.find(w => w.id === lastId) || index[0];
      
      if (lastWorkflow) {
        loadWorkflow(lastWorkflow.id, index);
      } else {
        createNewWorkflow('New Workflow', index);
      }
    }
  }, [isReady, currentUser, INDEX_KEY, LAST_USED_KEY, loadWorkflow, createNewWorkflow]);

  // --- Autosave logic ---
  useEffect(() => {
    if (isReady && currentWorkflowId && currentUser) {
      const timer = setTimeout(() => {
        const state: WorkflowState = { nodes, edges, activeBranches };
        localStorage.setItem(`${storagePrefix}workflow_${currentWorkflowId}`, JSON.stringify(state));
        setIsSaving(true);
        setTimeout(() => setIsSaving(false), 2000);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [nodes, edges, activeBranches, isReady, currentWorkflowId, currentUser, storagePrefix]);

  const onNodesChange: OnNodesChange = useCallback((changes) => {
    if (changes.some(c => c.type === 'remove' || c.type === 'add')) recordHistory();
    onNodesChangeDefault(changes);
  }, [onNodesChangeDefault, recordHistory]);

  const onEdgesChange: OnEdgesChange = useCallback((changes) => {
    if (changes.some(c => c.type === 'remove' || c.type === 'add')) recordHistory();
    onEdgesChangeDefault(changes);
  }, [onEdgesChangeDefault, recordHistory]);

  const onConnect = useCallback((params: Connection) => {
    recordHistory();
    setEdges((eds) => addEdge({ 
      ...params, 
      type: 'buttonEdge', 
      animated: true, 
      markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' },
      style: { stroke: '#3b82f6', strokeWidth: 2.5 }
    }, eds));
  }, [setEdges, recordHistory]);

  const onConnectStart = useCallback((_: any, { nodeId }: OnConnectStartParams) => {
    connectingNodeId.current = nodeId;
    isCancelledRef.current = false;
  }, []);

  const onConnectEnd = useCallback(
    (event: MouseEvent | TouchEvent) => {
      if (!connectingNodeId.current || isCancelledRef.current) {
        connectingNodeId.current = null;
        isCancelledRef.current = false;
        return;
      }
      const target = event.target as Element;
      const isPane = target.classList.contains('react-flow__pane') || target.classList.contains('react-flow__background');
      if (isPane) {
        const { clientX, clientY } = 'changedTouches' in event ? event.changedTouches[0] : (event as MouseEvent);
        const position = screenToFlowPosition({ x: clientX, y: clientY });
        const mouseEvent = event as MouseEvent;
        const isShift = mouseEvent.shiftKey;
        const isCtrlOrCmd = mouseEvent.ctrlKey || mouseEvent.metaKey;
        let mapping = NODE_CREATION_MAPPINGS.DEFAULT;
        if (isShift && isCtrlOrCmd) mapping = NODE_CREATION_MAPPINGS.COMBINED;
        else if (isShift) mapping = NODE_CREATION_MAPPINGS.SHIFT;
        else if (isCtrlOrCmd) mapping = NODE_CREATION_MAPPINGS.MODIFIER;
        recordHistory();
        const id = `node-${Date.now()}`;
        const newNode: Node<CanvasNodeData> = {
          id,
          type: mapping.type,
          position,
          zIndex: 1,
          data: {
            label: mapping.label,
            type: mapping.type,
            prompt: '',
            input: '',
            output: '',
            runState: RunState.IDLE,
            isDirty: false,
            shape: 'rounded',
          },
        };
        const edgeId = `edge-${connectingNodeId.current}-${id}`;
        const newEdge: Edge = {
          id: edgeId,
          source: connectingNodeId.current,
          target: id,
          type: 'buttonEdge',
          animated: true,
          markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6' },
          style: { stroke: '#3b82f6', strokeWidth: 2.5 }
        };
        setNodes((nds) => nds.concat(newNode));
        setEdges((eds) => eds.concat(newEdge));
        setSelectedNodeId(id);
      }
      connectingNodeId.current = null;
    },
    [screenToFlowPosition, setNodes, setEdges, recordHistory]
  );

  const updateNodeData = useCallback((id: string, newData: Partial<CanvasNodeData>) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === id) return { ...node, data: { ...node.data, ...newData } };
        return node;
      })
    );
  }, [setNodes]);

  const deleteNode = useCallback((id: string) => {
    recordHistory();
    setNodes((nds) => nds.filter((n) => n.id !== id));
    setEdges((eds) => eds.filter((e) => e.source !== id && e.target !== id));
    setSelectedNodeId(null);
  }, [setNodes, setEdges, recordHistory]);

  const addNode = useCallback((type: NodeType) => {
    recordHistory();
    const id = `node-${Date.now()}`;
    let position = { x: 100, y: 100 };
    const isSticky = type === NodeType.STICKY_NOTE;
    const newNode: Node<CanvasNodeData> = {
      id,
      type,
      position,
      zIndex: isSticky ? -10 : 1,
      data: {
        label: `New ${type}`,
        type,
        prompt: '',
        input: '',
        output: '',
        runState: RunState.IDLE,
        isDirty: false,
        shape: isSticky ? 'rectangle' : 'rounded',
        bgColor: isSticky ? 'rgba(30, 41, 59, 0.6)' : undefined,
      },
    };
    setNodes((nds) => [...nds, newNode]);
    setSelectedNodeId(id);
  }, [setNodes, recordHistory]);

  const runNode = useCallback(async (id: string) => {
    const nodeToRun = nodes.find(n => n.id === id);
    if (!nodeToRun || nodeToRun.data.type === NodeType.STICKY_NOTE) return;
    updateNodeData(id, { runState: RunState.RUNNING });
    try {
      const upstreamEdges = edges.filter((e) => e.target === id);
      const contextParts = upstreamEdges.map((edge) => {
        const sourceNode = nodes.find((n) => n.id === edge.source);
        return sourceNode ? `[Source: ${sourceNode.data.label}]\n${sourceNode.data.output || sourceNode.data.input}` : '';
      });
      const context = contextParts.filter(Boolean).join('\n\n---\n\n');
      let result = "";
      if (nodeToRun.data.type === NodeType.DATA_INPUT) result = nodeToRun.data.input;
      else result = await geminiService.runPrompt(nodeToRun.data.prompt, context);
      updateNodeData(id, { output: result, runState: RunState.RAN, isDirty: false });
    } catch (error) {
      console.error(error);
      updateNodeData(id, { runState: RunState.ERROR });
    }
  }, [nodes, edges, updateNodeData]);

  // --- Tips Logic ---
  const handleOpenTips = () => {
    setShuffledTips(shuffleArray(TIPS));
    setCurrentTipIndex(0);
    setIsTipsExpanded(true);
  };

  const handleNextTip = () => {
    setTipFade(true);
    setTimeout(() => {
      setCurrentTipIndex((prev) => (prev + 1) % shuffledTips.length);
      setTipFade(false);
    }, 200);
  };

  const handlePrevTip = () => {
    setTipFade(true);
    setTimeout(() => {
      setCurrentTipIndex((prev) => (prev - 1 + shuffledTips.length) % shuffledTips.length);
      setTipFade(false);
    }, 200);
  };

  // --- UI Handlers ---

  const handleCopy = useCallback(() => {
    if (!selectedNodeId) return;
    const nodeToCopy = nodes.find(n => n.id === selectedNodeId);
    if (!nodeToCopy) return;

    clipboard.current = {
      nodes: [JSON.parse(JSON.stringify(nodeToCopy))],
      edges: []
    };
    
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  }, [nodes, selectedNodeId]);

  const handlePaste = useCallback(() => {
    if (!clipboard.current || !clipboard.current.nodes.length) return;
    
    recordHistory();
    const newNodes = clipboard.current.nodes.map(node => {
      const id = `node-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      return {
        ...node,
        id,
        position: {
          x: node.position.x + 40,
          y: node.position.y + 40,
        },
        selected: false,
      };
    });

    setNodes((nds) => nds.concat(newNodes));
    if (newNodes.length > 0) {
      setSelectedNodeId(newNodes[0].id);
    }
  }, [setNodes, recordHistory]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && connectingNodeId.current) isCancelledRef.current = true;
      const target = e.target as HTMLElement;
      const isInInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;
      if (isInInput) return;
      if (e.metaKey || e.ctrlKey) {
        if (e.key === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
        else if (e.key === 'y') { e.preventDefault(); redo(); }
        else if (e.key === 'c') { e.preventDefault(); handleCopy(); }
        else if (e.key === 'v') { e.preventDefault(); handlePaste(); }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo, handleCopy, handlePaste]);

  const selectedNode = useMemo(() => nodes.find((n) => n.id === selectedNodeId) || null, [nodes, selectedNodeId]);

  const upstreamNodes = useMemo(() => {
    if (!selectedNodeId) return [];
    
    const ancestors = new Set<string>();
    const queue = [selectedNodeId];
    
    while (queue.length > 0) {
      const currentId = queue.shift()!;
      const parentEdges = edges.filter(e => e.target === currentId);
      for (const edge of parentEdges) {
        if (!ancestors.has(edge.source)) {
          ancestors.add(edge.source);
          queue.push(edge.source);
        }
      }
    }

    return Array.from(ancestors).map((id) => {
      const sourceNode = nodes.find((n) => n.id === id);
      if (!sourceNode) return null;
      return {
        id: sourceNode.id,
        label: sourceNode.data.label,
        output: sourceNode.data.output || sourceNode.data.input || '',
      };
    }).filter((n): n is { id: string, label: string, output: string } => n !== null);
  }, [nodes, edges, selectedNodeId]);

  const handleSaveAs = () => {
    if (!saveAsName.trim()) return;
    const id = `wf-${Date.now()}`;
    const newMetadata = { id, name: saveAsName, lastModified: new Date().toISOString() };
    const updatedIndex = [newMetadata, ...workflows];
    persistWorkflowsIndex(updatedIndex);
    localStorage.setItem(`${storagePrefix}workflow_${id}`, JSON.stringify({ nodes, edges, activeBranches }));
    setCurrentWorkflowId(id);
    setCurrentWorkflowName(saveAsName);
    setIsSaveAsOpen(false);
    setSaveAsName('');
  };

  const exportWorkflow = useCallback(() => {
    const state: WorkflowState = { nodes, edges, activeBranches };
    const jsonString = JSON.stringify(state, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentWorkflowName.replace(/\s+/g, '_')}_export.json`;
    link.click();
    URL.revokeObjectURL(url);
  }, [nodes, edges, activeBranches, currentWorkflowName]);

  const importWorkflow = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (f) => {
      try {
        const importedState: WorkflowState = JSON.parse(f.target?.result as string);
        if (importedState.nodes && Array.isArray(importedState.nodes)) {
          recordHistory();
          setNodes(importedState.nodes);
          setEdges(importedState.edges || []);
          setActiveBranches(importedState.activeBranches || {});
          setTimeout(() => fitView({ padding: 0.2 }), 100);
        }
      } catch (err) {
        console.error("Import failed:", err);
      }
    };
    reader.readAsText(file);
    if (e.target) e.target.value = '';
  }, [setNodes, setEdges, fitView, recordHistory]);

  if (!isReady) return null;

  return (
    <div className="flex h-screen w-screen bg-[#020617] text-slate-200 overflow-hidden font-sans">
      <input type="file" ref={fileInputRef} onChange={importWorkflow} accept=".json" className="hidden" />
      
      {/* Canvas Area with anchored UI components */}
      <div className="flex-1 relative flex flex-col">
        {isSaving && (
          <div className="absolute bottom-20 right-8 z-[100] bg-slate-900/90 backdrop-blur-xl border border-slate-700/50 px-4 py-2 rounded-full flex items-center gap-2 shadow-2xl transition-all animate-in slide-in-from-bottom-2">
            <Loader2 size={12} className="text-blue-500 animate-spin" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Saved</span>
          </div>
        )}

        {copyFeedback && (
          <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-[100] bg-emerald-600 text-white px-6 py-2 rounded-full flex items-center gap-2 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <ClipboardCheck size={18} />
            <span className="text-sm font-bold">Selection Copied!</span>
          </div>
        )}

        {/* Modern Tips Footer System - Anchored to Canvas */}
        <div 
          className={`absolute bottom-0 left-0 right-0 z-[100] transition-all duration-500 ease-in-out ${
            isTipsExpanded ? 'h-14 bg-slate-900/95 border-t border-slate-800 backdrop-blur-2xl' : 'h-0 pointer-events-none'
          }`}
        >
          <div className={`flex items-center justify-between h-full px-6 transition-opacity duration-300 ${isTipsExpanded ? 'opacity-100' : 'opacity-0'}`}>
            <div className="flex items-center gap-4 flex-1 overflow-hidden">
              <div className="bg-amber-500/10 p-2 rounded-lg border border-amber-500/20 flex-shrink-0">
                <Lightbulb size={16} className="text-amber-500" />
              </div>
              <div className="flex items-center gap-4 flex-1 min-w-0 overflow-hidden">
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={handlePrevTip} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-white transition-all"><ChevronLeft size={16} /></button>
                  <button onClick={handleNextTip} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-white transition-all"><ChevronRight size={16} /></button>
                </div>
                <div className="flex-1 overflow-hidden relative h-full flex items-center">
                  <p 
                    ref={tipTextRef}
                    className={`text-xs font-medium text-slate-300 whitespace-nowrap transition-all duration-200 ${tipFade ? 'opacity-0 translate-x-4' : 'opacity-100 translate-x-0'} ${isMarqueeActive ? 'animate-tip-marquee pl-4' : ''}`}
                    style={{ animationPlayState: isTipsExpanded ? 'running' : 'paused' }}
                  >
                    {shuffledTips[currentTipIndex]}
                  </p>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsTipsExpanded(false)}
              className="p-2 hover:bg-slate-800 rounded-full text-slate-500 hover:text-white transition-all pointer-events-auto flex-shrink-0 ml-4"
              title="Collapse Tips"
            >
              <Minimize2 size={16} />
            </button>
          </div>
        </div>

        {/* Muted Tips Toggle Button - Anchored to Canvas */}
        {!isTipsExpanded && (
          <button
            onClick={handleOpenTips}
            className="absolute bottom-6 right-6 z-[100] flex items-center gap-2 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 px-4 py-2 rounded-full shadow-2xl transition-all group active:scale-95"
          >
            <Lightbulb size={14} className="text-amber-500 opacity-60 group-hover:opacity-100" />
            <span className="text-[10px] font-bold text-slate-500 group-hover:text-slate-300 uppercase tracking-[0.2em]">View Tips</span>
            <Maximize2 size={12} className="text-slate-600" />
          </button>
        )}

        <div className="flex-1 relative">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onConnectStart={onConnectStart}
            onConnectEnd={onConnectEnd}
            onNodeClick={(_, node) => setSelectedNodeId(node.id)}
            onPaneClick={() => setSelectedNodeId(null)}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            onNodeDragStop={() => recordHistory()}
            fitView
            className="bg-slate-950"
            snapToGrid
            snapGrid={[15, 15]}
          >
            <Background color="#1e293b" gap={25} size={1} />
            <Controls className="!bg-slate-900 !border-slate-800 mb-12" />
            
            {/* Panels inside ReactFlow naturally move with the container */}
            <Panel position="top-left" className="flex flex-col gap-3 p-2">
              <div className="bg-slate-900/80 backdrop-blur-md p-2 rounded-2xl border border-slate-800 shadow-2xl flex flex-col gap-2">
                <div className="flex items-center gap-3 px-3 py-1 border-b border-slate-800 mb-1">
                  <Plus size={12} className="text-blue-500" />
                  <span className="text-xs font-bold uppercase tracking-widest text-slate-400 truncate max-w-[150px]">{currentWorkflowName}</span>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => addNode(NodeType.AI_PROMPT)} title="AI Logic" className="p-2.5 bg-purple-600/10 hover:bg-purple-600 text-purple-400 hover:text-white rounded-xl border border-purple-500/20"><Brain size={18} /></button>
                  <button onClick={() => addNode(NodeType.DATA_INPUT)} title="Data Source" className="p-2.5 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white rounded-xl border border-blue-500/20"><Database size={18} /></button>
                  <button onClick={() => addNode(NodeType.REFACTOR)} title="Transformation" className="p-2.5 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded-xl border border-emerald-500/20"><Rotate3d size={18} /></button>
                  <button onClick={() => addNode(NodeType.STICKY_NOTE)} title="Sticky Note" className="p-2.5 bg-amber-600/10 hover:bg-amber-600 text-amber-400 hover:text-white rounded-xl border border-amber-500/20"><StickyIcon size={18} /></button>
                </div>
              </div>
            </Panel>

            <Panel position="top-center" className="p-2">
              <div className="bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-full border border-slate-800 shadow-2xl flex items-center gap-4">
                {currentUser ? (
                  <>
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-blue-600/20 rounded-full border border-blue-500/20">
                        <UserIcon size={14} className="text-blue-400" />
                      </div>
                      <span className="text-[11px] font-bold text-slate-400">{currentUser.email}</span>
                    </div>
                    <div className="w-px h-4 bg-slate-800" />
                    <button onClick={logout} className="flex items-center gap-2 text-slate-500 hover:text-red-400 transition-colors">
                      <LogOut size={14} />
                      <span className="text-[10px] font-bold uppercase tracking-widest">Logout</span>
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => { setAuthMode('login'); setIsAuthModalOpen(true); }}
                    className="flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors px-2"
                  >
                    <LogIn size={14} />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Login / Signup</span>
                  </button>
                )}
              </div>
            </Panel>

            <Panel position="top-right" className="flex gap-2 p-2">
              <div className="bg-slate-900/80 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800 shadow-2xl flex gap-1">
                <button onClick={() => undo()} disabled={history.length === 0} className="p-2.5 disabled:opacity-30 bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl"><Undo2 size={18} /></button>
                <button onClick={() => redo()} disabled={future.length === 0} className="p-2.5 disabled:opacity-30 bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl"><Redo2 size={18} /></button>
                <div className="w-px bg-slate-800 mx-1" />
                <button onClick={() => setIsManagerOpen(true)} className="p-2.5 bg-slate-800/50 hover:bg-slate-800 text-blue-400 hover:text-white rounded-xl"><FolderOpen size={18} /></button>
                <button onClick={() => setIsSaveAsOpen(true)} className="p-2.5 bg-slate-800/50 hover:bg-slate-800 text-amber-400 hover:text-white rounded-xl"><GitFork size={18} /></button>
                <div className="w-px bg-slate-800 mx-1" />
                <button onClick={exportWorkflow} className="p-2.5 bg-slate-800/50 hover:bg-slate-800 text-emerald-400 hover:text-white rounded-xl"><Download size={18} /></button>
                <button onClick={() => fileInputRef.current?.click()} className="p-2.5 bg-slate-800/50 hover:bg-slate-800 text-cyan-400 hover:text-white rounded-xl"><Upload size={18} /></button>
              </div>
            </Panel>
          </ReactFlow>
        </div>
      </div>

      <NodeEditor
        node={selectedNode}
        onUpdate={updateNodeData}
        onRun={runNode}
        onDelete={deleteNode}
        onClose={() => setSelectedNodeId(null)}
        upstreamNodes={upstreamNodes}
      />

      {/* Auth Modal */}
      {isAuthModalOpen && (
        <div className="absolute inset-0 z-[200] flex items-center justify-center p-8 bg-black/80 backdrop-blur-xl">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.5)] w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-8 py-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-xl font-bold text-white">{authMode === 'login' ? 'Welcome Back' : 'Create Account'}</h3>
                  <p className="text-xs text-slate-500 mt-1">{authMode === 'login' ? 'Login to access your logic canvas' : 'Start building your AI workflows'}</p>
                </div>
                <button onClick={() => setIsAuthModalOpen(false)} className="p-2 rounded-full hover:bg-slate-800 text-slate-500"><CloseIcon size={20} /></button>
              </div>

              {authError && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs font-bold flex items-center gap-2">
                  <Info size={14} /> {authError}
                </div>
              )}

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Email Address</label>
                  <div className="relative">
                    <LogIn size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input 
                      type="email" 
                      value={authEmail} 
                      onChange={e => setAuthEmail(e.target.value)} 
                      placeholder="alice@example.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Password</label>
                  <div className="relative">
                    <Key size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" />
                    <input 
                      type="password" 
                      value={authPassword} 
                      onChange={e => setAuthPassword(e.target.value)} 
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-11 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                      onKeyDown={e => e.key === 'Enter' && handleAuth()}
                    />
                  </div>
                </div>

                {/* Remember Me Checkbox */}
                <div className="flex items-center gap-3 px-1 py-1 group">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <div className="relative w-4 h-4">
                      <input 
                        type="checkbox" 
                        checked={rememberMe} 
                        onChange={e => setRememberMe(e.target.checked)}
                        className="peer appearance-none w-4 h-4 bg-slate-950 border border-slate-700 rounded transition-all checked:bg-blue-600 checked:border-blue-500 cursor-pointer"
                      />
                      <Check className="absolute top-0 left-0 w-4 h-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity pointer-events-none p-0.5" strokeWidth={4} />
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 group-hover:text-slate-400 uppercase tracking-widest transition-colors">Remember me for 30 days</span>
                  </label>
                </div>

                <button 
                  onClick={handleAuth}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-sm shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] mt-2"
                >
                  {authMode === 'login' ? 'Login to Workspace' : 'Sign Up Now'}
                </button>

                <div className="text-center mt-6">
                  <button 
                    onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setAuthError(''); }}
                    className="text-[11px] font-bold text-slate-500 hover:text-blue-400 transition-colors uppercase tracking-widest"
                  >
                    {authMode === 'login' ? "Don't have an account? Sign Up" : "Already have an account? Login"}
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-slate-800/30 px-8 py-4 border-t border-slate-800/50">
              <p className="text-[10px] text-slate-600 text-center leading-relaxed">
                Workflows are stored in your browser's local storage and are isolated per account.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Workflow Manager Modal */}
      {isManagerOpen && (
        <div className="absolute inset-0 z-[110] flex items-center justify-center p-8 bg-black/60 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl w-full max-w-2xl max-h-[70vh] flex flex-col overflow-hidden">
            <div className="px-8 py-6 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-xl font-bold flex items-center gap-3"><FolderOpen className="text-blue-400" /> Workflow Library</h3>
              <button onClick={() => setIsManagerOpen(false)} className="p-2 rounded-full hover:bg-slate-800"><CloseIcon size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
              <button onClick={() => createNewWorkflow('New Workflow')} className="w-full flex items-center gap-3 p-4 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 hover:bg-blue-600/20 font-bold text-sm mb-2"><PlusSquare size={18} /> New Empty Workflow</button>
              {workflows.map(wf => (
                <div key={wf.id} onClick={() => loadWorkflow(wf.id)} className={`group flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${currentWorkflowId === wf.id ? 'bg-blue-600/10 border-blue-500/50' : 'bg-slate-900/50 border-slate-800 hover:bg-slate-800'}`}>
                  <div className="flex items-center gap-4">
                    <History size={18} className={currentWorkflowId === wf.id ? 'text-blue-400' : 'text-slate-600'} />
                    <div>
                      <div className="font-bold text-slate-200">{wf.name}</div>
                      <div className="text-[10px] text-slate-500">Modified: {new Date(wf.lastModified).toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onPointerDown={(e) => e.stopPropagation()}
                      onMouseDown={(e) => e.stopPropagation()}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        deleteWorkflow(wf.id);
                      }} 
                      className="p-3 text-slate-400 hover:text-red-500 hover:bg-red-500/20 rounded-xl transition-all border border-slate-800 hover:border-red-500/30 z-[120]"
                    >
                      <Trash2 size={18} className="pointer-events-none" />
                    </button>
                    <ChevronRight size={18} className="text-slate-700" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Save As / Fork Modal */}
      {isSaveAsOpen && (
        <div className="absolute inset-0 z-[120] flex items-center justify-center p-8 bg-black/60 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-lg font-bold flex items-center gap-2"><GitFork size={18} className="text-amber-400" /> Fork into New Workflow</h3>
              <button onClick={() => setIsSaveAsOpen(false)}><CloseIcon size={20} /></button>
            </div>
            <div className="p-6 space-y-4">
              <input autoFocus type="text" value={saveAsName} onChange={(e) => setSaveAsName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSaveAs()} placeholder="Name your fork..." className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-medium" />
              <div className="flex gap-2">
                <button onClick={() => setIsSaveAsOpen(false)} className="flex-1 py-3 rounded-xl bg-slate-800 font-bold">Cancel</button>
                <button onClick={handleSaveAs} className="flex-1 py-3 rounded-xl bg-blue-600 font-bold">Fork Workflow</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes tip-marquee {
          0% { transform: translateX(0); }
          10% { transform: translateX(0); }
          90% { transform: translateX(calc(-100% + 400px)); }
          100% { transform: translateX(calc(-100% + 400px)); }
        }
        .animate-tip-marquee {
          animation: tip-marquee 15s linear infinite alternate;
        }
      `}</style>
    </div>
  );
};

export default function App() {
  return (
    <ReactFlowProvider>
      <AppContent />
    </ReactFlowProvider>
  );
}
