
import React from 'react';
import { Node } from 'reactflow';
import { CanvasNodeData, NodeType, RunState } from '../types';
import { 
  Play, 
  Trash2, 
  X as CloseIcon, 
  Square, 
  Circle, 
  Diamond,
  Code2,
  Sparkles,
  Database,
  Terminal,
  ArrowDownToLine,
  Info,
  StickyNote as StickyIcon,
  Palette
} from 'lucide-react';

interface NodeEditorProps {
  node: Node<CanvasNodeData> | null;
  onUpdate: (id: string, newData: Partial<CanvasNodeData>) => void;
  onRun: (id: string) => void;
  onDelete: (id: string) => void;
  onClose: () => void;
  // Added to show what context this node is receiving
  upstreamContext?: string;
}

const PRESET_COLORS = [
  { name: 'Slate', value: 'rgba(30, 41, 59, 0.6)' },
  { name: 'Amber', value: 'rgba(180, 83, 9, 0.6)' },
  { name: 'Emerald', value: 'rgba(4, 120, 87, 0.6)' },
  { name: 'Rose', value: 'rgba(190, 18, 60, 0.6)' },
  { name: 'Indigo', value: 'rgba(67, 56, 202, 0.6)' },
  { name: 'Purple', value: 'rgba(126, 34, 206, 0.6)' },
  { name: 'Cyan', value: 'rgba(14, 116, 144, 0.6)' },
];

const NodeEditor: React.FC<NodeEditorProps> = ({ node, onUpdate, onRun, onDelete, onClose, upstreamContext }) => {
  if (!node) return null;

  const { data } = node;
  const isDataNode = data.type === NodeType.DATA_INPUT;
  const isLogicNode = data.type === NodeType.AI_PROMPT;
  const isRefactorNode = data.type === NodeType.REFACTOR;
  const isStickyNode = data.type === NodeType.STICKY_NOTE;

  return (
    <div className="w-[420px] bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-[-10px_0_40px_rgba(0,0,0,0.5)] overflow-hidden z-30 animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold flex items-center gap-2 text-white">
            {isDataNode && <Database size={18} className="text-blue-400" />}
            {isLogicNode && <Sparkles size={18} className="text-purple-400" />}
            {isRefactorNode && <Terminal size={18} className="text-emerald-400" />}
            {isStickyNode && <StickyIcon size={18} className="text-amber-400" />}
            {isDataNode ? 'Data Provider' : isLogicNode ? 'Logic Processor' : isRefactorNode ? 'Refactor Tool' : 'Sticky Note'}
          </h2>
          <span className="text-[10px] font-bold text-slate-500 font-mono tracking-widest uppercase mt-1">Ref ID: {node.id}</span>
        </div>
        <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-800 text-slate-500 hover:text-white transition-all">
          <CloseIcon size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
        {/* Sticky Note Aesthetics */}
        {isStickyNode && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-1 h-4 bg-amber-500 rounded-full" />
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Note Aesthetics</label>
            </div>
            <div className="flex flex-wrap gap-2">
              {PRESET_COLORS.map((color) => (
                <button
                  key={color.value}
                  onClick={() => onUpdate(node.id, { bgColor: color.value })}
                  title={color.name}
                  className={`w-8 h-8 rounded-lg border-2 transition-all hover:scale-110 active:scale-95 ${
                    data.bgColor === color.value ? 'border-white' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: color.value }}
                />
              ))}
              <div className="relative w-8 h-8 rounded-lg border-2 border-slate-700 hover:border-slate-500 transition-all flex items-center justify-center overflow-hidden bg-slate-800">
                <Palette size={14} className="text-slate-400" />
                <input 
                  type="color" 
                  value={data.bgColor?.startsWith('rgba') ? '#1e293b' : (data.bgColor || '#1e293b')}
                  onChange={(e) => onUpdate(node.id, { bgColor: e.target.value })}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
            </div>
          </section>
        )}

        {/* Type Selection (Quick Switch) */}
        {!isStickyNode && (
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-1 h-4 bg-purple-500 rounded-full" />
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Functionality</label>
              </div>
              <div className="group relative">
                <Info size={14} className="text-slate-600" />
                <div className="absolute right-0 bottom-6 w-48 bg-slate-800 text-[10px] p-2 rounded shadow-xl border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  {isDataNode ? 'Data nodes hold static content (JSON, Code, Text) to be consumed by logic nodes.' : 'Logic nodes use AI to process data from nodes connected above them.'}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: NodeType.AI_PROMPT, label: 'Logic', desc: 'AI Prompt' },
                { id: NodeType.DATA_INPUT, label: 'Data', desc: 'Raw Input' },
                { id: NodeType.REFACTOR, label: 'Patch', desc: 'Transform' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => onUpdate(node.id, { type: t.id as NodeType })}
                  className={`px-3 py-3 rounded-xl border transition-all flex flex-col items-center gap-1 ${
                    data.type === t.id
                      ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20 scale-[1.02]'
                      : 'bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-300'
                  }`}
                >
                  <span className="text-[11px] font-bold uppercase">{t.label}</span>
                  <span className="text-[8px] opacity-60 tracking-wider">{t.desc}</span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Name Input - Hidden for sticky notes as it's not needed */}
        {!isStickyNode && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-1 h-4 bg-blue-500 rounded-full" />
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Step Label</label>
            </div>
            <input
              type="text"
              value={data.label}
              onChange={(e) => onUpdate(node.id, { label: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium text-slate-200"
              placeholder="e.g. 'User Profile JSON' or 'Summarization Logic'..."
            />
          </section>
        )}

        {/* Upstream Context Preview */}
        {!isDataNode && !isStickyNode && upstreamContext && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-1 h-4 bg-indigo-500 rounded-full" />
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Incoming Context</label>
            </div>
            <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800/50 text-[10px] font-mono text-slate-500 max-h-32 overflow-y-auto custom-scrollbar">
              {upstreamContext}
            </div>
          </section>
        )}

        {/* Primary Input Textarea */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className={`w-1 h-4 rounded-full ${isDataNode ? 'bg-blue-500' : isStickyNode ? 'bg-amber-500' : 'bg-emerald-500'}`} />
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
                {isDataNode ? 'Payload Content (Literal)' : isStickyNode ? 'Markdown Content' : 'Prompt Instruction (Directives)'}
              </label>
            </div>
            {isLogicNode && <Sparkles size={14} className="text-blue-400 animate-pulse" />}
            {isStickyNode && <span className="text-[10px] text-slate-500 font-mono">Documentation Only</span>}
          </div>
          <div className="relative">
            <textarea
              rows={isStickyNode ? 15 : 10}
              value={isDataNode || isStickyNode ? data.input : data.prompt}
              onChange={(e) => {
                const field = isDataNode || isStickyNode ? 'input' : 'prompt';
                onUpdate(node.id, { [field]: e.target.value, isDirty: true });
              }}
              placeholder={isDataNode ? "Paste literal JSON, XML, or Text here..." : isStickyNode ? "Write Markdown here..." : "Instruct the AI on how to handle the incoming context..."}
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono resize-none leading-relaxed text-slate-300 custom-scrollbar ring-inset"
            />
            {(isDataNode || isStickyNode) && (
              <div className="absolute bottom-4 right-4 text-[9px] font-bold text-blue-500/40 uppercase pointer-events-none">
                {isStickyNode ? 'Markdown View' : 'Raw Storage'}
              </div>
            )}
          </div>
          {isStickyNode && (
            <p className="text-[10px] text-slate-500 italic px-2">
              Supports: # Headings, * bullets, **bold**, [links](url), `code`
            </p>
          )}
        </section>

        {/* Output Area */}
        {data.output && !isStickyNode && (
          <section className="space-y-4 pb-10">
            <div className="flex items-center gap-2">
              <span className="w-1 h-4 bg-slate-600 rounded-full" />
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
                {isDataNode ? 'Published State' : 'AI Execution Result'}
              </label>
            </div>
            <div className="bg-black/50 rounded-2xl p-5 border border-slate-800/50 text-[11px] font-mono text-slate-400 leading-relaxed max-h-[300px] overflow-y-auto custom-scrollbar shadow-inner group">
              <div className="flex justify-between items-start mb-3">
                 <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase ${isDataNode ? 'bg-blue-900/40 text-blue-400' : 'bg-emerald-900/40 text-emerald-400'}`}>
                   {isDataNode ? 'DATA_READY' : 'GENERATED_RESPONSE'}
                 </span>
                 <Code2 size={14} className="text-slate-700" />
              </div>
              <div className="whitespace-pre-wrap">{data.output}</div>
            </div>
          </section>
        )}
      </div>

      {/* Footer Actions */}
      <div className={`p-6 bg-slate-900 border-t border-slate-800 grid ${isStickyNode ? 'grid-cols-1' : 'grid-cols-2'} gap-4 sticky bottom-0 z-10 backdrop-blur-xl`}>
        {!isStickyNode && (
          <button
            onClick={() => onRun(node.id)}
            disabled={data.runState === RunState.RUNNING}
            className={`flex items-center justify-center gap-3 font-bold py-3.5 rounded-2xl transition-all shadow-lg active:scale-[0.98] disabled:scale-100 ${
              isDataNode 
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 shadow-slate-900/20' 
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/20'
            }`}
          >
            {data.runState === RunState.RUNNING ? (
              <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <>
                {isDataNode ? <ArrowDownToLine size={18} /> : <Play size={18} fill="currentColor" />}
                <span className="text-sm">{isDataNode ? 'Publish Data' : 'Run Logic'}</span>
              </>
            )}
          </button>
        )}
        <button
          onClick={() => onDelete(node.id)}
          className={`flex items-center justify-center gap-3 bg-red-950/20 hover:bg-red-900/30 text-red-400 border border-red-900/20 py-3.5 rounded-2xl transition-all active:scale-[0.98] ${isStickyNode ? 'w-full' : ''}`}
        >
          <Trash2 size={18} />
          <span className="text-sm font-bold">Delete {isStickyNode ? 'Note' : 'Node'}</span>
        </button>
      </div>
    </div>
  );
};

export default NodeEditor;
