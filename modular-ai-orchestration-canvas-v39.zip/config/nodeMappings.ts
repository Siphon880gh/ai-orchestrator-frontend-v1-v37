import { NodeType } from '../types';

export interface ModifierMapping {
  type: NodeType;
  label: string;
}

/**
 * Mappings for creating nodes via drag-and-release on the canvas.
 */
export const NODE_CREATION_MAPPINGS = {
  AI: {
    type: NodeType.AI_PROMPT,
    label: 'AI Intelligence',
  },
  DATA: {
    type: NodeType.DATA_INPUT,
    label: 'Data Source',
  },
  TRANSFORM: {
    type: NodeType.REFACTOR,
    label: 'Refactor Step',
  },
  CODE: {
    type: NodeType.CODE,
    label: 'Code Block',
  },
  API: {
    type: NodeType.API_REQUEST,
    label: 'API Integration',
  },
};