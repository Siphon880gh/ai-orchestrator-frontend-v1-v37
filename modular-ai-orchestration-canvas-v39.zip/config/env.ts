export const envConfig = {
  /**
   * Set to true to display the Test Harness / Simulation Environment.
   * Set to false to display the main app.
   */
  testMode: false
};
