
# Modular AI Orchestration Canvas

A visual IDE for AI workflow design, allowing users to map, execute, and refactor complex logic using a dynamic branching flowchart.

## 🛠 Testing & Coverage

The project uses a hybrid testing strategy combining automated unit tests with an interface-driven integration harness.

### 1. Enable the Test Interface
To run integration tests within the browser:
1. Open `config/env.ts`.
2. Set `testMode: true`.
3. The app will reload into the **Test Harness UI**, where you can trigger storage-specific CRUD flows and multi-user isolation tests.

### 2. Automated Unit Tests (Vitest)
Core logic, including the `StorageService` and `Interpolation Engine`, is covered by Vitest.
- **Run tests**: `npm test`
- **Watch mode**: `npm run test:watch`
- **Generate coverage**: `npm run test:coverage`

### 3. Coverage Reports
The project generates coverage in multiple formats:
- **Text**: Summary displayed in the terminal after running tests.
- **HTML**: Detailed report viewable in `coverage/index.html`.
- **LCOV**: Found in `coverage/lcov.info` for CI integration.

### 4. CI/CD Enforcement
GitHub Actions is configured to run tests on every pull request. The build **will fail** if coverage falls below these thresholds:
- Statements: 80%
- Branches: 75%
- Functions: 85%

### Uncovered Areas (TODO)
- [ ] UI visual regressions (requires Playwright/Cypress integration).
- [ ] Multi-touch gesture edge cases on the React Flow canvas.
- [ ] Gemini API streaming error states (mocking required).

Refer to [misc-test-plan.md](./misc-test-plan.md) for the full strategy.
