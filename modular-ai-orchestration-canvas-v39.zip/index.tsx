
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import TestHarness from './components/TestHarness.tsx';
import { envConfig } from './config/env.ts';

// Global handler to suppress benign ResizeObserver loop limit errors
if (typeof window !== 'undefined') {
  window.addEventListener('error', (e) => {
    const isResizeObserverError = 
      e.message === 'ResizeObserver loop completed with undelivered notifications.' || 
      e.message === 'ResizeObserver loop limit exceeded';
      
    if (isResizeObserverError) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }
  });
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

// Environment Switcher Logic (Config Driven + LocalStorage for UI toggling)
const isSimulation = envConfig.testMode || localStorage.getItem('env_mode') === 'test';

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    {isSimulation ? <TestHarness /> : <App />}
  </React.StrictMode>
);
