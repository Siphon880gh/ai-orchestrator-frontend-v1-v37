import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { User as UserIcon, LogIn, Trash2, ShieldCheck, Database, RefreshCw, AlertCircle, ExternalLink, ArrowLeft } from 'lucide-react';

const USERS_KEY = 'modular_ai_canvas_users';

const SimulationDashboard = () => {
    const [logs, setLogs] = useState<string[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [currentUser, setCurrentUser] = useState<string | null>(null);

    const log = (msg: string) => {
        setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);
    };

    useEffect(() => {
        const stored = localStorage.getItem(USERS_KEY);
        if (stored) setUsers(JSON.parse(stored));
    }, []);

    const clearAll = () => {
        if (confirm("Clear ALL local storage data?")) {
            localStorage.clear();
            sessionStorage.clear();
            setUsers([]);
            setCurrentUser(null);
            log("Storage cleared completely.");
        }
    };

    const createUser = (email: string) => {
        const newUser = { email, password: 'password' };
        const updated = [...users, newUser];
        localStorage.setItem(USERS_KEY, JSON.stringify(updated));
        setUsers(updated);
        log(`Created user: ${email}`);
    };

    const loginAs = (email: string) => {
        setCurrentUser(email);
        log(`Simulating login for ${email}`);
        const sessionData = { email, password: 'password', expiresAt: Date.now() + 1000000 };
        localStorage.setItem('modular_ai_canvas_session', JSON.stringify(sessionData));
    };

    const exitSimulation = () => {
        localStorage.setItem('env_mode', 'live');
        window.location.reload();
    };

    const checkIsolation = () => {
        const results = users.map(u => {
            const prefix = `user_${u.email.replace(/[@.]/g, '_')}_`;
            const indexKey = `${prefix}modular_ai_canvas_index`;
            const workflows = JSON.parse(localStorage.getItem(indexKey) || '[]');
            return { email: u.email, count: workflows.length };
        });
        
        log("ISOLATION REPORT:");
        results.forEach(r => log(`- ${r.email}: ${r.count} workflows`));
    };

    const runAutoTest = async () => {
        log("Starting Auto-Test: Multi-User Workflow Isolation...");
        
        localStorage.clear();
        const emailA = "alpha@test.com";
        const emailB = "beta@test.com";
        
        createUser(emailA);
        loginAs(emailA);
        const prefixA = `user_${emailA.replace(/[@.]/g, '_')}_`;
        localStorage.setItem(`${prefixA}modular_ai_canvas_index`, JSON.stringify([{ id: 'wf-1', name: 'Alpha Workflow', lastModified: new Date().toISOString() }]));
        log(`User A created 'Alpha Workflow'`);

        createUser(emailB);
        loginAs(emailB);
        const prefixB = `user_${emailB.replace(/[@.]/g, '_')}_`;
        localStorage.setItem(`${prefixB}modular_ai_canvas_index`, JSON.stringify([{ id: 'wf-2', name: 'Beta Workflow', lastModified: new Date().toISOString() }]));
        log(`User B created 'Beta Workflow'`);

        const workflowsA = JSON.parse(localStorage.getItem(`${prefixA}modular_ai_canvas_index`) || '[]');
        const workflowsB = JSON.parse(localStorage.getItem(`${prefixB}modular_ai_canvas_index`) || '[]');
        
        if (workflowsA.length === 1 && workflowsA[0].name === 'Alpha Workflow' && 
            workflowsB.length === 1 && workflowsB[0].name === 'Beta Workflow') {
            log("SUCCESS: Workflows are isolated by user prefix.");
        } else {
            log("FAILURE: Data leakage detected.");
        }
    };

    return (
        <div className="min-h-screen bg-[#020617] text-slate-200 p-8 font-sans overflow-auto custom-scrollbar">
            <div className="max-w-4xl mx-auto">
                <header className="mb-8 flex items-center justify-between border-b border-slate-800 pb-4">
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            <ShieldCheck className="text-emerald-400" />
                            Canvas Integration Simulator
                        </h1>
                        <p className="text-slate-400 text-sm mt-1 uppercase tracking-widest font-bold">QA Testing Environment</p>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={exitSimulation} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-sm font-bold transition-all flex items-center gap-2 text-slate-300">
                            <ArrowLeft size={16} /> Exit to Main App
                        </button>
                        <button onClick={runAutoTest} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-sm font-bold transition-all flex items-center gap-2">
                            <RefreshCw size={16} /> Run Full Auto-Test
                        </button>
                    </div>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-6">
                        <section className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-2">
                                <UserIcon size={16} className="text-blue-400" /> User Simulation
                            </h2>
                            <div className="space-y-3">
                                <button onClick={() => createUser(`user${users.length + 1}@test.com`)} className="w-full p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-700">
                                    + Add New Test User
                                </button>
                                <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                                    {users.map(u => (
                                        <div key={u.email} className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800/50 text-[10px] group">
                                            <span className="truncate flex-1 font-mono text-slate-400 group-hover:text-slate-200 transition-colors">{u.email}</span>
                                            <button onClick={() => loginAs(u.email)} className={`px-2 py-1 rounded-md font-bold transition-all ${currentUser === u.email ? 'bg-emerald-600 text-white' : 'bg-blue-600/10 text-blue-400 hover:bg-blue-600/20'}`}>
                                                {currentUser === u.email ? 'ACTIVE' : 'LOGIN'}
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </section>

                        <section className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-2">
                                <Database size={16} className="text-emerald-400" /> State Inspector
                            </h2>
                            <div className="space-y-2">
                                <button onClick={checkIsolation} className="w-full p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-700">
                                    Run Isolation Check
                                </button>
                                <button onClick={clearAll} className="w-full p-2.5 bg-red-900/10 hover:bg-red-900/30 text-red-500 rounded-xl text-xs font-bold transition-all border border-red-900/20">
                                    Wipe Storage (Reset)
                                </button>
                            </div>
                        </section>
                    </div>

                    <div className="md:col-span-2 space-y-4">
                        <div className="bg-slate-950/60 rounded-3xl p-6 border border-slate-800 h-[600px] flex flex-col shadow-2xl">
                            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                                Execution Trace
                            </h2>
                            <div className="flex-1 overflow-y-auto font-mono text-[11px] space-y-1.5 custom-scrollbar pr-2">
                                {logs.length === 0 && <p className="text-slate-700 italic">Awaiting test sequence initialization...</p>}
                                {logs.map((l, i) => (
                                    <div key={i} className={`pb-1 border-b border-slate-900/30 ${l.includes('SUCCESS') ? 'text-emerald-400 bg-emerald-400/5 p-1 rounded' : l.includes('FAILURE') ? 'text-red-400 bg-red-400/5 p-1 rounded' : 'text-slate-400'}`}>
                                        {l}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SimulationDashboard;