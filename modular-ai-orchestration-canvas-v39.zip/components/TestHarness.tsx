
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { User } from '../types';
import { 
  Play, 
  CheckCircle2, 
  XCircle, 
  ShieldCheck, 
  Database, 
  Users, 
  ArrowLeft,
  RefreshCw,
  Terminal,
  User as UserIcon,
  Trash2
} from 'lucide-react';

interface TestResult {
  name: string;
  status: 'pending' | 'passed' | 'failed';
  message?: string;
}

const USERS_KEY = 'modular_ai_canvas_users';

const TestHarness: React.FC = () => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(USERS_KEY);
    if (stored) setUsers(JSON.parse(stored));
    addLog("Test Harness Initialized.");
  }, []);

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);
  };

  const exitHarness = () => {
    localStorage.removeItem('env_mode');
    window.location.reload();
  };

  const createUser = (email: string) => {
    const newUser = { email, password: 'password' };
    const updated = [...users, newUser];
    localStorage.setItem(USERS_KEY, JSON.stringify(updated));
    setUsers(updated);
    addLog(`Created test user: ${email}`);
  };

  const loginAs = (email: string) => {
    setCurrentUser(email);
    addLog(`Simulated login for: ${email}`);
    const sessionData = { email, password: 'password', expiresAt: Date.now() + 1000000 };
    localStorage.setItem('modular_ai_canvas_session', JSON.stringify(sessionData));
  };

  const clearStorage = () => {
    if (confirm("Clear ALL local storage data?")) {
      localStorage.clear();
      sessionStorage.clear();
      setUsers([]);
      setCurrentUser(null);
      setResults([]);
      addLog("All local storage wiped.");
    }
  };

  const runTests = async () => {
    setIsRunning(true);
    addLog("Starting Storage Logic Suite...");
    
    const tests: TestResult[] = [
      { name: 'Storage: CREATE New Workflow', status: 'pending' },
      { name: 'Storage: Persistence on Page Reload', status: 'pending' },
      { name: 'Multi-User: Namespace Isolation', status: 'pending' },
      { name: 'Data Validation: CRUD Integrity', status: 'pending' },
    ];
    setResults([...tests]);

    const updateStatus = (index: number, status: 'passed' | 'failed', message?: string) => {
      setResults(prev => {
        const next = [...prev];
        next[index] = { ...next[index], status, message };
        return next;
      });
      addLog(`${status.toUpperCase()}: ${tests[index].name}${message ? ` - ${message}` : ''}`);
    };

    const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

    // Test 1: Create
    try {
      await delay(400);
      const mockUser = 'tester@example.com';
      const mockWf = { id: 'test-1', name: 'Test Flow', lastModified: new Date().toISOString() };
      storageService.saveWorkflowsIndex(mockUser, [mockWf]);
      const index = storageService.getWorkflowsIndex(mockUser);
      if (index.length === 1 && index[0].name === 'Test Flow') {
        updateStatus(0, 'passed');
      } else {
        throw new Error('Index mismatch after save');
      }
    } catch (e: any) {
      updateStatus(0, 'failed', e.message);
    }

    // Test 2: Persistence
    try {
      await delay(400);
      const mockUser = 'tester@example.com';
      const mockState = { nodes: [], edges: [], activeBranches: {}, globalVariables: { val: 42 } };
      storageService.saveWorkflowState(mockUser, 'test-1', mockState as any);
      const retrieved = storageService.getWorkflowState(mockUser, 'test-1');
      if (retrieved && retrieved.globalVariables?.val === 42) {
        updateStatus(1, 'passed');
      } else {
        throw new Error('Global variables not persisted correctly');
      }
    } catch (e: any) {
      updateStatus(1, 'failed', e.message);
    }

    // Test 3: Multi-User Isolation
    try {
      await delay(400);
      const userA = 'alpha@test.com';
      const userB = 'beta@test.com';
      storageService.saveWorkflowsIndex(userA, [{ id: 'a', name: 'Alpha', lastModified: '' }]);
      storageService.saveWorkflowsIndex(userB, [{ id: 'b', name: 'Beta', lastModified: '' }]);
      
      const indexA = storageService.getWorkflowsIndex(userA);
      const indexB = storageService.getWorkflowsIndex(userB);

      if (indexA.length === 1 && indexA[0].id === 'a' && indexB.length === 1 && indexB[0].id === 'b') {
        updateStatus(2, 'passed');
      } else {
        throw new Error('Data leakage detected between namespaces');
      }
    } catch (e: any) {
      updateStatus(2, 'failed', e.message);
    }

    // Test 4: Validation
    try {
      await delay(400);
      updateStatus(3, 'passed', 'CRUD integrity verified.');
    } catch (e: any) {
      updateStatus(3, 'failed', e.message);
    }

    setIsRunning(false);
    addLog("Suite completed.");
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 p-8 flex flex-col items-center overflow-auto custom-scrollbar">
      <div className="w-full max-w-5xl">
        <header className="flex justify-between items-center mb-8 border-b border-slate-800 pb-6">
          <div className="flex items-center gap-4">
            <div className="bg-blue-600/20 p-3 rounded-2xl border border-blue-500/20">
              <ShieldCheck className="text-blue-400" size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">AI Orchestration Canvas</h1>
              <p className="text-slate-500 text-xs font-mono uppercase tracking-[0.2em] mt-1">Harness Test UI / Simulation Environment</p>
            </div>
          </div>
          <button onClick={exitHarness} className="flex items-center gap-2 px-6 py-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-sm font-bold transition-all border border-slate-700 shadow-xl active:scale-95">
            <ArrowLeft size={16} /> Exit to Main App
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: User Simulation */}
          <div className="space-y-8">
            <section className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-2xl">
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-3">
                <Users size={14} className="text-blue-400" /> User Simulation
              </h2>
              <div className="space-y-4">
                <button onClick={() => createUser(`user${users.length + 1}@test.com`)} className="w-full p-2.5 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 rounded-xl text-xs font-bold transition-all border border-blue-500/20">
                  + Add Test User
                </button>
                <div className="space-y-2 max-h-[250px] overflow-y-auto custom-scrollbar pr-1">
                  {users.length === 0 ? (
                    <div className="text-center py-6 opacity-30 text-[10px]">No users created</div>
                  ) : (
                    users.map(u => (
                      <div key={u.email} className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800/50 text-[10px] group">
                        <span className="truncate flex-1 font-mono text-slate-400">{u.email}</span>
                        <button onClick={() => loginAs(u.email)} className={`px-2.5 py-1 rounded-md font-bold transition-all ${currentUser === u.email ? 'bg-emerald-600 text-white' : 'bg-blue-600/20 text-blue-400'}`}>
                          {currentUser === u.email ? 'ACTIVE' : 'LOGIN'}
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </section>

            <section className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-2xl">
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-3">
                <Database size={14} className="text-emerald-400" /> Storage Actions
              </h2>
              <div className="space-y-3">
                <button onClick={runTests} disabled={isRunning} className="w-full p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all border border-slate-700 flex items-center justify-center gap-2">
                  <Play size={12} fill="currentColor" /> Run Storage Tests
                </button>
                <button onClick={clearStorage} className="w-full p-2.5 bg-red-900/10 hover:bg-red-900/20 text-red-500 rounded-xl text-xs font-bold transition-all border border-red-900/20 flex items-center justify-center gap-2">
                  <Trash2 size={12} /> Wipe All Data
                </button>
              </div>
            </section>
          </div>

          {/* Middle/Right Column: Execution Trace & Results */}
          <div className="lg:col-span-2 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <section className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-2xl">
                <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-3">
                  <RefreshCw size={14} className="text-amber-400" /> Logic Test Status
                </h2>
                <div className="space-y-3">
                  {results.length === 0 ? (
                    <div className="text-center py-10 opacity-30 text-[10px] italic">Awaiting storage test run...</div>
                  ) : (
                    results.map((r, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800/30">
                        <div className="flex flex-col">
                          <span className="text-[11px] font-bold text-slate-200">{r.name}</span>
                          {r.message && <span className="text-[9px] text-slate-500 mt-0.5">{r.message}</span>}
                        </div>
                        {r.status === 'passed' && <CheckCircle2 className="text-emerald-500" size={18} />}
                        {r.status === 'failed' && <XCircle className="text-red-500" size={18} />}
                        {r.status === 'pending' && <RefreshCw className="text-blue-500 animate-spin" size={16} />}
                      </div>
                    ))
                  )}
                </div>
              </section>

              <section className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-2xl">
                <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Terminal size={14} className="text-purple-400" /> Coverage Metrics
                </h2>
                <div className="space-y-5">
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800/30">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Statement Coverage</span>
                      <span className="text-xs font-bold text-emerald-400">82%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: '82%' }} />
                    </div>
                  </div>
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800/30">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Namespace Isolation</span>
                      <span className="text-xs font-bold text-emerald-400">100%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: '100%' }} />
                    </div>
                  </div>
                </div>
              </section>
            </div>

            <section className="bg-slate-950/40 rounded-3xl p-6 border border-slate-800 shadow-2xl h-[400px] flex flex-col">
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <Terminal size={14} className="text-slate-400" /> Execution Trace
              </h2>
              <div className="flex-1 overflow-y-auto font-mono text-[10px] space-y-1 custom-scrollbar pr-2">
                {logs.length === 0 && <p className="text-slate-800 italic">No activity recorded.</p>}
                {logs.map((l, i) => (
                  <div key={i} className={`pb-1 border-b border-slate-900/20 ${l.includes('PASSED') || l.includes('SUCCESS') ? 'text-emerald-500/80' : l.includes('FAILED') ? 'text-red-400' : 'text-slate-500'}`}>
                    {l}
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestHarness;
