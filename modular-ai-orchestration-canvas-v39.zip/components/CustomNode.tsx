import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { CanvasNodeData, NodeType, RunState } from '../types';
import * as LucideIcons from 'lucide-react';
import { Brain, Database, AlertCircle, CheckCircle2, MessageSquareText, Terminal, SatelliteDish, Rotate3d } from 'lucide-react';

const CustomNode = ({ data, selected, targetPosition = Position.Top, sourcePosition = Position.Bottom }: NodeProps<CanvasNodeData>) => {
  const isAi = data.type === NodeType.AI_PROMPT;
  const isData = data.type === NodeType.DATA_INPUT;
  const isRefactor = data.type === NodeType.REFACTOR;
  const isCode = data.type === NodeType.CODE;
  const isApi = data.type === NodeType.API_REQUEST;

  // Dynamically resolve custom icon
  const CustomIcon = data.icon && (LucideIcons as any)[data.icon] ? (LucideIcons as any)[data.icon] : null;

  const getGlowStyles = () => {
    if (!data.glowColor || !data.glowIntensity) return {};
    const intensityMap = [0, 10, 20, 40]; // Pixel values for shadow spread
    const spread = intensityMap[data.glowIntensity] || 0;
    if (spread === 0) return {};
    return {
      boxShadow: `0 0 ${spread}px ${data.glowColor}`,
      borderColor: data.glowColor
    };
  };

  const getBorderColor = () => {
    if (data.runState === RunState.RUNNING) return 'border-blue-500 shadow-lg shadow-blue-500/20';
    if (data.runState === RunState.ERROR) return 'border-red-500 shadow-lg shadow-red-500/20';
    if (data.runState === RunState.RAN) return 'border-green-500/50';
    return selected ? 'border-blue-400' : 'border-slate-700';
  };

  // Default Node Rendering (All logic nodes now use this unified rounded rectangle style)
  return (
    <div 
      className={`min-w-[220px] max-w-[280px] bg-slate-900 border-2 transition-all duration-300 ${getBorderColor()} rounded-2xl shadow-xl`}
      style={getGlowStyles()}
    >
      <Handle type="target" position={targetPosition} className="!bg-slate-500 !w-2 !h-2" />
      
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {CustomIcon ? (
              <CustomIcon size={16} style={{ color: data.glowColor || 'inherit' }} />
            ) : (
              <>
                {isAi && <Brain size={16} className="text-purple-400" />}
                {isData && <Database size={16} className="text-blue-400" />}
                {isRefactor && <Rotate3d size={16} className="text-emerald-400" />}
                {isCode && <Terminal size={16} className="text-amber-400" />}
                {isApi && <SatelliteDish size={16} className="text-cyan-400" />}
              </>
            )}
            <span className="font-semibold text-xs uppercase tracking-wider text-slate-400">
              {data.label || 'New Node'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {data.comment && <span title="Has internal comment" className="flex items-center"><MessageSquareText size={12} className="text-slate-500" /></span>}
            <div className="flex items-center gap-1">
              {data.runState === RunState.RUNNING && <div className="animate-spin h-3 w-3 border-2 border-blue-400 border-t-transparent rounded-full" />}
              {data.runState === RunState.RAN && <CheckCircle2 size={14} className="text-green-500" />}
              {data.runState === RunState.ERROR && <AlertCircle size={14} className="text-red-500" />}
            </div>
          </div>
        </div>

        <div className="text-sm text-slate-300 line-clamp-3 bg-slate-800/50 p-2 rounded border border-slate-700/50 min-h-[60px] font-mono">
          {isApi ? (data.url || 'No URL...') : (data.prompt || data.input || 'Empty...')}
        </div>

        {data.isDirty && data.runState === RunState.RAN && (
          <div className="mt-2 text-[10px] text-yellow-500/80 italic">
            Outdated - re-run required
          </div>
        )}
      </div>

      <Handle type="source" position={sourcePosition} className="!bg-blue-500 !w-2 !h-2" />
    </div>
  );
};

export default memo(CustomNode);