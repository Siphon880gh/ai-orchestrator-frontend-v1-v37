
import { WorkflowState, WorkflowMetadata, User } from '../types';

export class StorageService {
  private getPrefix(userEmail: string | null): string {
    const email = userEmail || 'guest';
    return `user_${email.replace(/[@.]/g, '_')}_`;
  }

  getWorkflowsIndex(userEmail: string | null): WorkflowMetadata[] {
    const key = `${this.getPrefix(userEmail)}modular_ai_canvas_index`;
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  }

  saveWorkflowsIndex(userEmail: string | null, index: WorkflowMetadata[]): void {
    const key = `${this.getPrefix(userEmail)}modular_ai_canvas_index`;
    localStorage.setItem(key, JSON.stringify(index));
  }

  getWorkflowState(userEmail: string | null, workflowId: string): WorkflowState | null {
    const key = `${this.getPrefix(userEmail)}workflow_${workflowId}`;
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  }

  saveWorkflowState(userEmail: string | null, workflowId: string, state: WorkflowState): void {
    const key = `${this.getPrefix(userEmail)}workflow_${workflowId}`;
    localStorage.setItem(key, JSON.stringify(state));
  }

  deleteWorkflow(userEmail: string | null, workflowId: string): void {
    const key = `${this.getPrefix(userEmail)}workflow_${workflowId}`;
    localStorage.removeItem(key);
  }

  getLastUsedId(userEmail: string | null): string | null {
    const key = `${this.getPrefix(userEmail)}modular_ai_canvas_last_used`;
    return localStorage.getItem(key);
  }

  setLastUsedId(userEmail: string | null, id: string): void {
    const key = `${this.getPrefix(userEmail)}modular_ai_canvas_last_used`;
    localStorage.setItem(key, id);
  }
}

export const storageService = new StorageService();
