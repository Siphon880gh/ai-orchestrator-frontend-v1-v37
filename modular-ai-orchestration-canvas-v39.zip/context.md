
# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Multi-User Authentication**, **Workflow Management**, and a robust **Interpolation Engine** for cross-node state persistence.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Testing**: Vitest + Unified TestHarness (Simulation UI)
- **Configuration**: Environment behavior managed via `config/env.ts` and runtime `localStorage` switches.

## File Tree & Roles
- `App.tsx`: Core hub managing auth, graph state, and interpolation logic.
- `services/storageService.ts`: Centralized storage logic for CRUD and multi-user isolation.
- `components/TestHarness.tsx`: Unified interface-driven test environment for simulating storage, users, and namespaces.
- `types.ts`: Shared data models.
- `components/NodeEditor.tsx`: Configuration UI with interpolation previews.
- `tests/storage.test.ts`: Automated unit tests for data reliability.
- `config/env.ts`: Static configuration for environment modes.

## Quality Assurance
The codebase maintains high stability through:
1. **User Flow Documentation**: Detailed in `misc-user-flows.md`.
2. **Comprehensive Test Plan**: Detailed in `misc-test-plan.md`.
3. **Automated Coverage**: Enforced via Vitest in CI/CD.
4. **Test Harness**: A robust simulation UI that validates storage persistence and multi-user isolation. Triggered by a button in `App.tsx` or `testMode: true` in config.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.
