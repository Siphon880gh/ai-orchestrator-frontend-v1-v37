
# Test Plan: Modular AI Orchestration Canvas

## 1. Scope & Priorities (Data Storage Focus)
The primary testing objective is to ensure the integrity, isolation, and persistence of user workflow data.
- **Critical**: Data Isolation (User A cannot access User B's workflows).
- **Critical**: CRUD Reliability (Ensuring Workflows are correctly saved, retrieved, and deleted).
- **High**: Interpolation Logic (evaluating `{}` tags against the data layer).

## 2. Test Types
- **Unit Testing**: Focuses on the `StorageService` and `resolveInterpolation` utility.
- **Integration Testing**: Interface-driven tests executed within the `TestHarness` UI.
- **API Simulation**: Validating that nodes targeting external URLs handle JSON and raw text correctly.
- **Regression**: Automated CI checks ensuring new features don't break existing storage namespaces.

## 3. Tools & Framework
- **Primary Tool**: **Vitest** (standard for React/TypeScript projects).
- **Interface Harness**: Custom `TestHarness.tsx` component for browser-side integration tests.
- **CI Environment**: GitHub Actions running `npm run test:coverage`.

## 4. Coverage Goals
- **Statements**: > 80%
- **Branches**: > 75%
- **Functions**: > 85%
- **Storage Service Coverage**: 100% (Mandatory for CRUD operations).

## 5. Proven Storage Features (CRUD Flow)
1. **CREATE**: Prove that creating a workflow generates a unique ID and persists the metadata to the index.
2. **READ**: Prove that reloading the page with a specific ID retrieves the correct node graph.
3. **UPDATE**: Prove that the 1.5s autosave pulse correctly syncs the graph state to `localStorage`.
4. **DELETE**: Prove that deleting a workflow removes the state and updates the index without affecting other users.

## 6. Interface-Driven Execution
The `TestHarness` UI provides a centralized dashboard to:
- Trigger the full integration test suite via a "Run All" button.
- Visualize real-time status of storage operations.
- Inspect coverage summaries for multi-user isolation.
- To enable: set `testMode: true` in `config/env.ts`.

## 7. Multi-User Verification
Isolation is tested by:
- Simulating logins for multiple test accounts (e.g., alpha@test.com, beta@test.com).
- Verifying that storage keys are correctly prefixed (e.g., `user_alpha_test_com_`).
- Asserting that operations in one namespace never overwrite or query another.
