# Context: Node Architecture & UI

*Note: Approximate location references are intentional.*

## Node Data Model (`types.ts`)
Nodes store metadata in their `data` object:
- `label`: Unique identifier used for referencing in curly braces.
- `glowColor` & `glowIntensity`: Drives CSS `boxShadow` effects. Intensity uses 4 levels: 0 (Off), 1 (Min), 2 (Mid), 3 (Max).
- `icon`: String reference to Lucide-React icon names.
- `chatHistory`: Persists conversational context for refinements.
- `comment`: Stores internal user annotations for each node.
- `url`, `method`, `payload`: Specific configurations for **API Request** nodes.

## Unique Naming Constraint
All nodes within a workflow must have unique labels.
- **Creation**: When a new node is created, the system checks for existing labels and appends a numeric suffix if needed (e.g., "New AI Logic 1", "New AI Logic 2").
- **Renaming**: The Node Editor validates new names against existing labels. If a duplicate is detected, a validation error is displayed and the update is blocked until a unique name is provided.

## Custom Node Rendering (`components/CustomNode.tsx`)
Nodes follow a consistent rounded rectangle visual style:
- **Icons**: Resolved dynamically from the `LucideIcons` library (near top of component). Uses `Brain` for AI Logic, `Database` for Data Sources, `Rotate3d` for Transformation steps, `Terminal` for custom JavaScript, and `SatelliteDish` for API Requests.
- **Auras**: The `getGlowStyles` function calculates shadow spread based on intensity levels (0-3).
- **Comments Indicator**: A small `MessageSquareText` icon appears in the node header if a comment exists.
- **Shapes**: All functional nodes use rounded rectangles; documentation uses `StickyNoteNode`.

## The Node Editor (`components/NodeEditor.tsx`)
The editor is the command center for node-specific logic and aesthetics:
- **Node Label Validation**: Ensures names are unique and provides visual feedback if a duplicate name is entered.
- **Node Comments**: A dedicated "Internal Annotations" section allows users to save private notes.
- **Visual Character Section**: Allows selecting from a curated list of logic-themed icons and vibrant glow colors. This section is **collapsible**.
- **Recall Feature**: A "Recall" button allows users to insert data from **any ancestor node** directly into the current text cursor position.
- **Intelligent Variable Recall**: Includes a **"Variable" checkbox** (checked by default). When checked, clicking an ancestor inserts the interpolation syntax `{ $("NODE NAME").output }`. When unchecked, it inserts the ancestor's current raw value.
- **Intelligent Recall Target**: For nodes with multiple text inputs (like API Request's URL and Payload), the Recall button automatically targets the **last focused text field** for injection.
- **API Specifics**: Dedicated fields for HTTP Method (dropdown), Target URL, and Request Payload.
- **Cursor Tracking**: Uses `useRef` and focus event listeners to track the active textarea, ensuring precise data injection.

## Workflow Interactions (`App.tsx`)
- **Copy/Paste**: Handled via `handleCopy` and `handlePaste`, allowing users to duplicate complex node structures while maintaining unique labels.
- **Expandable Tips Footer**: A "Muted" floating button that expands into a full-width footer on click.
- **Keyboard Shortcuts Modal**: A specialized help menu accessible from the expanded Tips Footer, detailing creation shortcuts.
- **Creation Shortcuts (Drag-from-Handle)**:
  - **SHIFT**: Data Source node.
  - **CTRL / CMD**: Transformation Step.
  - **ALT / OPT**: Code Block node.
  - **SHIFT+ALT / SHIFT+OPT**: API Integration node.
- **Deletion Shortcut**: Pressing **Delete** or **Backspace** while a node is selected removes it from the canvas.