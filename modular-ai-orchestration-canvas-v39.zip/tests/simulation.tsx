import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { User, WorkflowMetadata } from '../types';
import { User as UserIcon, LogIn, Trash2, ShieldCheck, Database, RefreshCw, AlertCircle, ExternalLink } from 'lucide-react';

const USERS_KEY = 'modular_ai_canvas_users';

const SimulationDashboard = () => {
    const [logs, setLogs] = useState<string[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [currentUser, setCurrentUser] = useState<string | null>(null);

    const log = (msg: string) => {
        setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);
    };

    useEffect(() => {
        const stored = localStorage.getItem(USERS_KEY);
        if (stored) setUsers(JSON.parse(stored));
    }, []);

    const clearAll = () => {
        if (confirm("Clear ALL local storage data?")) {
            localStorage.clear();
            sessionStorage.clear();
            setUsers([]);
            setCurrentUser(null);
            log("Storage cleared completely.");
        }
    };

    const createUser = (email: string) => {
        const newUser = { email, password: 'password' };
        const updated = [...users, newUser];
        localStorage.setItem(USERS_KEY, JSON.stringify(updated));
        setUsers(updated);
        log(`Created user: ${email}`);
    };

    const loginAs = (email: string) => {
        setCurrentUser(email);
        log(`Simulating login for ${email}`);
        // Simulate session state
        const sessionData = { email, password: 'password', expiresAt: Date.now() + 1000000 };
        localStorage.setItem('modular_ai_canvas_session', JSON.stringify(sessionData));
    };

    const launchMainApp = () => {
        localStorage.setItem('env_mode', 'live');
        window.location.href = '../index.html?test=false';
    };

    const checkIsolation = () => {
        const results = users.map(u => {
            const prefix = `user_${u.email.replace(/[@.]/g, '_')}_`;
            const indexKey = `${prefix}modular_ai_canvas_index`;
            const workflows = JSON.parse(localStorage.getItem(indexKey) || '[]');
            return { email: u.email, count: workflows.length };
        });
        
        log("ISOLATION REPORT:");
        results.forEach(r => log(`- ${r.email}: ${r.count} workflows`));
    };

    const runAutoTest = async () => {
        log("Starting Auto-Test: Multi-User Workflow Isolation...");
        
        // 1. Setup
        localStorage.clear();
        const emailA = "alpha@test.com";
        const emailB = "beta@test.com";
        
        // 2. User A actions
        createUser(emailA);
        loginAs(emailA);
        const prefixA = `user_${emailA.replace(/[@.]/g, '_')}_`;
        localStorage.setItem(`${prefixA}modular_ai_canvas_index`, JSON.stringify([{ id: 'wf-1', name: 'Alpha Workflow', lastModified: new Date().toISOString() }]));
        log(`User A created 'Alpha Workflow'`);

        // 3. User B actions
        createUser(emailB);
        loginAs(emailB);
        const prefixB = `user_${emailB.replace(/[@.]/g, '_')}_`;
        localStorage.setItem(`${prefixB}modular_ai_canvas_index`, JSON.stringify([{ id: 'wf-2', name: 'Beta Workflow', lastModified: new Date().toISOString() }]));
        log(`User B created 'Beta Workflow'`);

        // 4. Verification
        const workflowsA = JSON.parse(localStorage.getItem(`${prefixA}modular_ai_canvas_index`) || '[]');
        const workflowsB = JSON.parse(localStorage.getItem(`${prefixB}modular_ai_canvas_index`) || '[]');
        
        if (workflowsA.length === 1 && workflowsA[0].name === 'Alpha Workflow' && 
            workflowsB.length === 1 && workflowsB[0].name === 'Beta Workflow') {
            log("SUCCESS: Workflows are isolated by user prefix.");
        } else {
            log("FAILURE: Data leakage detected.");
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <header className="mb-8 flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                    <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                        <ShieldCheck className="text-emerald-400" />
                        Canvas Integration Simulator
                    </h1>
                    <p className="text-slate-400 text-sm mt-1">Testing persistence, auth, and multi-user isolation</p>
                </div>
                <div className="flex gap-2">
                    <button onClick={launchMainApp} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-sm font-bold transition-all flex items-center gap-2 text-slate-300">
                        <ExternalLink size={16} /> Launch Main App
                    </button>
                    <button onClick={runAutoTest} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-sm font-bold transition-all flex items-center gap-2">
                        <RefreshCw size={16} /> Run Full Auto-Test
                    </button>
                    <button onClick={clearAll} className="px-4 py-2 bg-red-900/30 hover:bg-red-800/50 text-red-400 border border-red-900/50 rounded-lg text-sm font-bold transition-all flex items-center gap-2">
                        <Trash2 size={16} /> Reset All
                    </button>
                </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-6">
                    <section className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
                        <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <UserIcon size={16} /> User Control
                        </h2>
                        <div className="space-y-2">
                            <button onClick={() => createUser(`user${users.length + 1}@test.com`)} className="w-full p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold transition-all">
                                Create Test User
                            </button>
                            <div className="pt-4 space-y-2">
                                {users.map(u => (
                                    <div key={u.email} className="flex items-center justify-between p-2 bg-slate-950 rounded-lg border border-slate-800 text-[10px]">
                                        <span className="truncate flex-1 font-mono">{u.email}</span>
                                        <button onClick={() => loginAs(u.email)} className={`px-2 py-1 rounded ${currentUser === u.email ? 'bg-emerald-600 text-white' : 'bg-blue-600/10 text-blue-400 hover:bg-blue-600/20'}`}>
                                            {currentUser === u.email ? 'Active' : 'Login'}
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </section>

                    <section className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
                        <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Database size={16} /> Inspection
                        </h2>
                        <button onClick={checkIsolation} className="w-full p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold transition-all">
                            Verify Data Isolation
                        </button>
                    </section>
                </div>

                <div className="md:col-span-2 space-y-4">
                    <div className="bg-black/40 rounded-2xl p-6 border border-slate-800 h-[600px] flex flex-col">
                        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Simulation Logs</h2>
                        <div className="flex-1 overflow-y-auto font-mono text-[11px] space-y-1 custom-scrollbar">
                            {logs.length === 0 && <p className="text-slate-700 italic">No logs yet. Start an action to see trace...</p>}
                            {logs.map((l, i) => (
                                <div key={i} className={`pb-1 border-b border-slate-900/50 ${l.includes('SUCCESS') ? 'text-emerald-400' : l.includes('FAILURE') ? 'text-red-400' : 'text-slate-400'}`}>
                                    {l}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            
            <footer className="mt-8 text-center text-[10px] text-slate-600 font-bold uppercase tracking-[0.3em]">
                Simulation Environment v1.0.0
            </footer>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('simulation-root')!);
root.render(<SimulationDashboard />);