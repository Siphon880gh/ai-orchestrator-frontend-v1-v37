
import { describe, it, expect, beforeEach } from 'vitest';
import { storageService } from '../services/storageService';

describe('StorageService CRUD & Isolation', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('should create and retrieve a workflow index for a specific user', () => {
    const user = 'alice@test.com';
    const mockWf = { id: 'wf-1', name: 'Flow 1', lastModified: '' };
    storageService.saveWorkflowsIndex(user, [mockWf]);
    
    const index = storageService.getWorkflowsIndex(user);
    expect(index).toHaveLength(1);
    expect(index[0].name).toBe('Flow 1');
  });

  it('should maintain strict isolation between user namespaces', () => {
    const userA = 'alpha@test.com';
    const userB = 'beta@test.com';
    
    storageService.saveWorkflowsIndex(userA, [{ id: 'a', name: 'Alpha', lastModified: '' }]);
    storageService.saveWorkflowsIndex(userB, [{ id: 'b', name: 'Beta', lastModified: '' }]);
    
    expect(storageService.getWorkflowsIndex(userA)).toHaveLength(1);
    expect(storageService.getWorkflowsIndex(userA)[0].id).toBe('a');
    expect(storageService.getWorkflowsIndex(userB)).toHaveLength(1);
    expect(storageService.getWorkflowsIndex(userB)[0].id).toBe('b');
  });

  it('should correctly save and retrieve workflow state', () => {
    const user = 'bob@test.com';
    const state = { nodes: [{ id: '1' }], edges: [], activeBranches: {}, globalVariables: { x: 10 } };
    storageService.saveWorkflowState(user, 'wf-1', state as any);
    
    const retrieved = storageService.getWorkflowState(user, 'wf-1');
    expect(retrieved).not.toBeNull();
    expect(retrieved?.globalVariables?.x).toBe(10);
    expect(retrieved?.nodes).toHaveLength(1);
  });

  it('should update the last used ID per user', () => {
    storageService.setLastUsedId('user1', 'id-1');
    storageService.setLastUsedId('user2', 'id-2');
    
    expect(storageService.getLastUsedId('user1')).toBe('id-1');
    expect(storageService.getLastUsedId('user2')).toBe('id-2');
  });
});
