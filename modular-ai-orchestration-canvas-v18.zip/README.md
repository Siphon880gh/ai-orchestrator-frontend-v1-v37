# Modular AI Orchestration Canvas

A visual IDE for AI workflow design, allowing users to map, execute, and refactor complex logic using a dynamic branching flowchart. This tool enables modular prompt engineering where AI responses can serve as context for subsequent logical steps.

- **Visual Orchestration**: Powered by React Flow for a seamless drag-and-drop experience.
- **AI-Native**: Deeply integrated with Google Gemini (Pro for logic, Flash for summarization).
- **Persistent Workspace**: Full support for multiple workflows, undo/redo history, and local storage persistence.
- **Modular Data Flow**: Nodes inherit context from all connected upstream parents.
- **Documentation Built-in**: Markdown-supported sticky notes for annotating complex logic graphs.

Refer to [context.md](./context.md) for high-level architectural details and [context-runtime.md](./context-runtime.md) for execution flow specifics.