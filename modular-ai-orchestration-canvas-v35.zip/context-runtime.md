# Context: Runtime & State Management

*Note: Approximate location references are intentional.*

## State Management (`App.tsx`)
The app uses a unified state for `nodes` and `edges`. 
- **Undo/Redo**: Controlled via `history` and `future` stacks. `recordHistory` clones the current graph state.
- **Autosave**: Persists the graph to `localStorage` every 1.5s after any change. A guard state `isInitialLoadComplete` prevents saving the default graph state over existing data during the boot sequence.

## Node Execution Logic
Found in the lower half of `App.tsx` within the `runNode` function:
1. Gathers `output` from all source nodes connected to the target.
2. Passes this combined string as "Upstream Context" to Gemini.
3. For **API Nodes**, performs a `fetch` request using the node's configured URL, Method, and Body.
4. For **Code Nodes**, executes procedurally with access to parent data.

## Chat Agent Logic (`services/geminiService.ts`)
The `GeminiService` class now supports stateful refinement:
- `sendChatMessage`: Uses `ai.chats.create` with a provided history and context-aware `systemInstruction`.
- It leverages the `gemini-3-pro-preview` model for advanced reasoning.

## Persistence & Storage Schema (Multi-User Aware)
The application relies on `localStorage` with user-prefixed keys for isolation:
1. **User Accounts (`modular_ai_canvas_users`)**:
   - Stores an array of `User` objects (email, password).
2. **Current Session (`modular_ai_canvas_session`)**:
   - Handles two types of sessions:
     - **Persistent**: If "Remember Me" is selected, the session is stored in `localStorage` with an `expiresAt` field (30 days).
     - **Temporary**: If unselected, the session is stored in `sessionStorage` and persists only until the tab/browser is closed.
   - On initialization, the app validates the session against the `expiresAt` timestamp.
3. **Workflow Index (`user_${email}_modular_ai_canvas_index`)**: 
   - Stores an array of `WorkflowMetadata` specific to the user.
4. **Workflow State (`user_${email}_workflow_${id}`)**: 
   - Stores the full `WorkflowState` object for a specific workflow.
5. **Session Restoration (`user_${email}_modular_ai_canvas_last_used`)**: 
   - Stores the string `id` of the user's last active workflow.

## Context Aggregation
Nodes do not just receive the prompt; they receive a structured snapshot of their parents' outputs. In Chat Mode, this context is provided as a System Instruction to ensure the AI "knows" what data it is helping the user process.
