# Project Context: Modular AI Orchestration Canvas

*Note: Approximate location references are intentional to maintain accuracy across refactors.*

## High-Level Description
The Modular AI Orchestration Canvas is a visual IDE for designing complex AI workflows. It represents logic as a Directed Acyclic Graph (DAG) where data and context flow from parents to children. Key features include **Multi-User Authentication**, **Workflow Management** (Naming, Forking, Library), **Interactive Chat Agents** for multi-turn refinement, **Visual Character Customization**, a robust **Ancestor Recall** system for raw data reuse across the entire logic chain, **Internal Annotations (Comments)** grouped with node labels for documentation, a modern **JS Execution Node** for procedural logic, a high-performance **API Request Node** for external integrations, and a modern, expandable **Tips Footer**.

## Tech Stack
- **Framework**: React 19
- **Graph Engine**: React Flow 11
- **LLM**: Google Gemini API (@google/genai)
- **Layout**: Dagre
- **Styling**: Tailwind CSS
- **Content**: Marked (Markdown rendering)

## File Tree & Roles
- `App.tsx`: The core hub. Manages auth, graph state, workflow lifecycle (naming, saving, loading), undo/redo, and the tips system. Uses `Brain`, `Database`, `Rotate3d`, `Terminal`, and `SatelliteDish` icons for workflow orchestration.
- `types.ts`: Defines data models, including `User` and `CanvasNodeData` which supports AI, Code, and API logic.
- `services/geminiService.ts`: Handles generation and stateful chat logic.
- `components/CustomNode.tsx`: Visual representation of logic nodes with custom icons, CSS "Auras", and metadata indicators (like comments).
- `components/NodeEditor.tsx`: Configuration UI for logic, aesthetics, and annotations.
- `components/StickyNoteNode.tsx`: Scalable documentation nodes with Markdown support.

## High-Level Code Flow
1. **Authentication**: Users login/signup to access their isolated workspace. Alice is pre-seeded for testing.
2. **Graph Construction**: Users add nodes via drag-and-create shortcuts or the toolbox.
3. **Workflow Management**: Users can name, fork (save as), and switch between multiple workflows using the Workflow Library.
4. **Visual Styling**: Nodes are customized with icons, glow effects, and internal comments.
5. **Execution**: Logic steps are executed. AI nodes aggregate upstream context; Data nodes publish raw input; **Code nodes execute arbitrary JavaScript**; **API Request nodes perform HTTP calls**.
6. **Data Reuse**: The "Recall" feature in the editor traverses the entire predecessor graph to allow injecting raw ancestor data into child prompts or API fields at the cursor position.
7. **Persistence**: Autosave triggers user-prefixed localStorage updates.

Refer to `context-runtime.md` for state details and `context-nodes.md` for UI/Node specifics.