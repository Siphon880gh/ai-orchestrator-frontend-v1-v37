# Context: Node Architecture & UI

*Note: Approximate location references are intentional.*

## Node Data Model (`types.ts`)
Nodes store metadata in their `data` object:
- `glowColor` & `glowIntensity`: Drives CSS `boxShadow` effects. Intensity uses 4 levels: 0 (Off), 1 (Min), 2 (Mid), 3 (Max).
- `icon`: String reference to Lucide-React icon names.
- `chatHistory`: Persists conversational context for refinements.
- `comment`: Stores internal user annotations for each node.
- `url`, `method`, `payload`: Specific configurations for **API Request** nodes.

## Custom Node Rendering (`components/CustomNode.tsx`)
Nodes are highly dynamic:
- **Icons**: Resolved dynamically from the `LucideIcons` library (near top of component). Uses `Brain` for AI Logic, `Database` for Data Sources, `Rotate3d` for Transformation steps, `Terminal` for custom JavaScript, and `SatelliteDish` for API Requests.
- **Auras**: The `getGlowStyles` function calculates shadow spread based on intensity levels (0-3).
- **Comments Indicator**: A small `MessageSquareText` icon appears in the node header if a comment exists.
- **Shapes**: Supports rounded rects and diamonds.

## The Node Editor (`components/NodeEditor.tsx`)
The editor is the command center for node-specific logic and aesthetics:
- **Node Comments**: A dedicated "Internal Annotations" section allows users to save private notes.
- **Visual Character Section**: Allows selecting from a curated list of logic-themed icons and vibrant glow colors. This section is **collapsible**.
- **Recall Feature**: A "Recall" button allows users to insert data from **any ancestor node** directly into the current text cursor position.
- **Intelligent Recall Target**: For nodes with multiple text inputs (like API Request's URL and Payload), the Recall button automatically targets the **last focused text field** for injection.
- **API Specifics**: Dedicated fields for HTTP Method (dropdown), Target URL, and Request Payload.
- **Cursor Tracking**: Uses `useRef` and focus event listeners to track the active textarea, ensuring precise data injection.

## Workflow Interactions (`App.tsx`)
- **Copy/Paste**: Handled via `handleCopy` and `handlePaste`, allowing users to duplicate complex node structures.
- **Expandable Tips Footer**: A "Muted" floating button that expands into a full-width footer on click.
- **Keyboard Shortcuts Modal**: A specialized help menu accessible from the expanded Tips Footer, detailing creation shortcuts (Shift, Cmd+Opt, 1, 2) and canvas operations.
- **Creation Shortcuts**: Rapid "type-aware" node creation using modifier keys.
- **Specific Shortcuts**: Holding **'1'** creates a Code node; holding **'2'** creates an API Request node; holding **'Shift'** creates a Data Source.
- **Deletion Shortcut**: Pressing **Delete** or **Backspace** while a node is selected removes it from the canvas.